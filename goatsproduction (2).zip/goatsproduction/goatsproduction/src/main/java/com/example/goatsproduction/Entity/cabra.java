package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

@Entity
public class cabra {
    public cabra(Long id) {
        this.id = id;
    }

    public cabra(Long id, String nombre, String fechaNacimiento, String fechaFallecimiento, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaFallecimiento = fechaFallecimiento;
        this.estado = estado;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;
    private String nombre;
    private String fechaNacimiento;
    private String fechaFallecimiento;
    private String estado;

    public cabra() {

    }

    public String getNombre() {
        return nombre;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getFechaFallecimiento() {
        return fechaFallecimiento;
    }

    public String getEstado() {
        return estado;
    }

    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setFechaFallecimiento(String fechaFallecimiento) {
        this.fechaFallecimiento = fechaFallecimiento;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
