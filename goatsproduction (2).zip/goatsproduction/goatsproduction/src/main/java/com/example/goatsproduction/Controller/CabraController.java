package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.cabra;
import com.example.goatsproduction.Service.CabraServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping()
@CrossOrigin()
public class CabraController {
    @Autowired
    private CabraServicio cabraServicio;

    @GetMapping
    public List<cabra> listarCabras() {

        return cabraServicio.obtenerTodas();
    }

    @PostMapping
    public cabra agregarCabra(@RequestBody cabra cabra) {
        return cabraServicio.guardarCabra(cabra);
    }

    @PutMapping("/Actualizar")
    public Optional<cabra> actualizarCabra(@PathVariable Long id, @RequestBody cabra cabra) {
        return cabraServicio.actualizarCabra(id, cabra);
    }

    @DeleteMapping("/Eliminar")
    public void eliminarCabra(@PathVariable Long id) {
        cabraServicio.eliminarCabra(id);
    }
}