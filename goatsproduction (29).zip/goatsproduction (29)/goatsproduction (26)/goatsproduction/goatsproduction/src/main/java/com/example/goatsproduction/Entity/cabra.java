package com.example.goatsproduction.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class cabra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cabra", nullable = false)
    private Long id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "color", nullable = false)
    private String color;

    @Column(name = "estado", nullable = false)
    private String estado;

    @Column(name = "estado_salud", nullable = false)
    private String estadoSalud;

    @Column(name = "descripcion", nullable = false)
    private String descripcion;

    @Column(name = "raza", nullable = false)
    private String raza;

    @Column(name = "fecha_nacimiento", nullable = false)
    private LocalDate fechaNacimiento;

    @Column(name = "fecha_fallecimiento")
    private LocalDate fechaFallecimiento;

    @Column(name = "fecha_salida_produccion")
    private LocalDate fechaSalidaProduccion;

    @OneToMany(mappedBy = "cabra", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Produccion> producciones = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "vacunas", joinColumns = @JoinColumn(name = "cabra_id"))
    @Column(name = "vacuna")
    private List<String> vacunacion = new ArrayList<>();

    // Constructor vacío
    public cabra() {
        this.vacunacion = new ArrayList<>();
        this.producciones = new ArrayList<>();
    }

    // Constructor con parámetros
    public cabra(Long id, String nombre, String color, String estado, String estadoSalud, String descripcion,
                 String raza, LocalDate fechaNacimiento, LocalDate fechaFallecimiento,
                 LocalDate fechaSalidaProduccion, List<String> vacunacion) {
        this.id = id;
        this.nombre = nombre;
        this.color = color;
        this.estado = estado;
        this.estadoSalud = estadoSalud;
        this.descripcion = descripcion;
        this.raza = raza;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaFallecimiento = fechaFallecimiento;
        this.fechaSalidaProduccion = fechaSalidaProduccion;
        this.vacunacion = vacunacion != null ? vacunacion : new ArrayList<>();
    }

    // Getters y setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getEstadoSalud() { return estadoSalud; }
    public void setEstadoSalud(String estadoSalud) { this.estadoSalud = estadoSalud; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getRaza() { return raza; }
    public void setRaza(String raza) { this.raza = raza; }

    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }

    public LocalDate getFechaFallecimiento() { return fechaFallecimiento; }
    public void setFechaFallecimiento(LocalDate fechaFallecimiento) { this.fechaFallecimiento = fechaFallecimiento; }

    public LocalDate getFechaSalidaProduccion() { return fechaSalidaProduccion; }
    public void setFechaSalidaProduccion(LocalDate fechaSalidaProduccion) { this.fechaSalidaProduccion = fechaSalidaProduccion; }

    public List<Produccion> getProducciones() { return producciones; }
    public void setProducciones(List<Produccion> producciones) { this.producciones = producciones != null ? producciones : new ArrayList<>(); }

    public List<String> getVacunacion() { return vacunacion; }
    public void setVacunacion(List<String> vacunacion) { this.vacunacion = vacunacion != null ? vacunacion : new ArrayList<>(); }
}
