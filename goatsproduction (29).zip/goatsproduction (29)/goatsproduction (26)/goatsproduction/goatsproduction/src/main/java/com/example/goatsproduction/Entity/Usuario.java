package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    @ManyToMany(mappedBy = "usuarios")  // Relación inversa
    private Set<Administrador> administradores = new HashSet<>();

    @ManyToMany
    @JoinTable(
            name = "usuario_producto",  // Nombre de la tabla intermedia
            joinColumns = @JoinColumn(name = "usuario_id"),  // Clave foránea de Usuario
            inverseJoinColumns = @JoinColumn(name = "producto_id")  // Clave foránea de Producto
    )

    private Set<producto> productos = new HashSet<>();

    public Usuario() {}

    public Usuario(Long id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

}
