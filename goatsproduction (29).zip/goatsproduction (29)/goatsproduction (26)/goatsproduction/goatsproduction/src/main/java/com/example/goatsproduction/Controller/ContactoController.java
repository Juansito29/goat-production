package com.example.goatsproduction.Controller;


import com.example.goatsproduction.Entity.Contacto;
import com.example.goatsproduction.Repository.ContactoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://127.0.0.1:5500/")
@RequestMapping("/api/contacto")
public class ContactoController {

    @Autowired
    private ContactoRepository contactoRepository;

    @PostMapping
    public ResponseEntity<String> handleContactForm(@RequestBody Contacto contacto) {
        try {
            // Aquí puedes imprimir para ver si los datos vienen bien
            System.out.println("Nombre: " + contacto.getNombre());
            System.out.println("Email: " + contacto.getEmail());
            System.out.println("Mensaje: " + contacto.getMensaje());

            contactoRepository.save(contacto);
            return ResponseEntity.ok("Mensaje enviado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
}