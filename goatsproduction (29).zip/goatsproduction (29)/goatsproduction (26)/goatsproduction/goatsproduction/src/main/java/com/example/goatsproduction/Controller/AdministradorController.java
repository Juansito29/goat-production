package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Administrador;
import com.example.goatsproduction.Security.JwtUtil;
import com.example.goatsproduction.Service.AdministradorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin("http://127.0.0.1:5500/")
@RestController
@RequestMapping("/auth/admin")
public class AdministradorController {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AdministradorService administradorService;

    // Registro de administrador
    @PostMapping("/registrart")
    public ResponseEntity<?> registrarAdministrador(@RequestBody Administrador administrador) {
        try {
            Administrador nuevoAdmin = administradorService.registrarAdministrador(administrador);
            return ResponseEntity.ok(nuevoAdmin);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Inicio de sesión del administrador
    @PostMapping("/loginn")
    public ResponseEntity<?> iniciarSesion(@RequestBody Administrador credenciales) {
        try {
            Administrador admin = administradorService.autenticarAdministrador(credenciales.getUsername(), credenciales.getPassword());

            UserDetails userDetails = org.springframework.security.core.userdetails.User
                    .withUsername(admin.getUsername())
                    .password(admin.getPassword())
                    .roles("ADMIN")
                    .build();
            String token = jwtUtil.generateToken(userDetails);
            return ResponseEntity.ok().body(Map.of("token", token));
        } catch (Exception e) {
            return ResponseEntity.status(401).body(e.getMessage());
        }
    }
}
