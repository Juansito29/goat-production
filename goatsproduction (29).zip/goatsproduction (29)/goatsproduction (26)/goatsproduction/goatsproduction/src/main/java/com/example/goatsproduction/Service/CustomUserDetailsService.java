package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Administrador;
import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.AdministradorRepository;
import com.example.goatsproduction.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private AdministradorRepository administradorRepository;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Administrador> admin = administradorRepository.findByUsername(username);
        if (admin.isPresent()) {
            Administrador a = admin.get();

            return User.builder()
                    .username(a.getUsername())
                    .password(a.getPassword())
                    .roles("ADMIN")
                    .build();
        }

        Optional<Usuario> usuario = usuarioRepository.findByUsername(username);
        if (usuario.isPresent()) {
            Usuario u = usuario.get();

            return User.builder()
                    .username(u.getUsername())
                    .password(u.getPassword())
                    .roles("ADMIN")
                    .build();
        }

        throw new UsernameNotFoundException("Usuario no encontrado" + username);

    }


}
