package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Security.JwtUtil;
import com.example.goatsproduction.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin("http://127.0.0.1:5500/")
@RestController
@RequestMapping("/auth/user")
public class UsuarioController {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/obtenerUsuarios")
    public List<Usuario> obtenerUsuarios() {
        return usuarioService.getAllUsuario();
    }

    // Registro de usuario
    @PostMapping("/registrarp")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        Usuario nuevoUsuario = usuarioService.registrarUsuario(usuario);
        return ResponseEntity.ok(nuevoUsuario);
    }

    // Inicio de sesión de usuario
    @PostMapping("/loginp")
    public ResponseEntity<?> loginUsuario(@RequestBody Usuario usuario) {
        Usuario usuarioAutenticado = usuarioService.autenticarUsuario(usuario.getUsername(), usuario.getPassword());
        if (usuarioAutenticado != null) {
            UserDetails userDetails = org.springframework.security.core.userdetails.User
                    .withUsername(usuarioAutenticado.getUsername())
                    .password(usuarioAutenticado.getPassword())
                    .roles("USER")
                    .build();

            String token = jwtUtil.generateToken(userDetails);
            return ResponseEntity.ok().body(Map.of("token", token));
        } else {
            return ResponseEntity.status(401).body("Usuario o contraseña incorrectos.");
        }
    }

}
