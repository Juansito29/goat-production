package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Pago;
import com.example.goatsproduction.Repository.PagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PagoServicio {

    @Autowired
    private PagoRepository pagoRepository;

    // Obtener todos los pagos
    public List<Pago> obtenerPagos() {
        return pagoRepository.findAll();
    }

    // Guardar un nuevo pago
    public Pago guardarPago(Pago pago) {
        return pagoRepository.save(pago);
    }

    // Obtener un pago por su ID
    public Optional<Pago> obtenerPagoPorId(Long id) {
        return pagoRepository.findById(id);
    }

    // Actualizar un pago existente
    public Optional<Pago> actualizarPago(Long id, Pago pagoActualizado) {
        return pagoRepository.findById(id).map(pagoExistente -> {
            pagoExistente.setMetodoPago(pagoActualizado.getMetodoPago()); // Actualizado
            pagoExistente.setMonto(pagoActualizado.getMonto());
            pagoExistente.setFechaPago(pagoActualizado.getFechaPago());
            return pagoRepository.save(pagoExistente);
        });
    }

    // Eliminar un pago por ID
    public boolean eliminarPago(Long id) {
        if (pagoRepository.existsById(id)) {
            pagoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
