package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.producto;
import com.example.goatsproduction.Service.ProductoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin("http://127.0.0.1:5500/")
public class ProductoController {

    @Autowired
    private ProductoServicio productoServicio;

    // Obtener todos los productos
    @GetMapping("/listars")
    public ResponseEntity<List<producto>> obtenerTodos() {
        List<producto> productos = productoServicio.obtenerProductos();
        return ResponseEntity.ok(productos);
    }

    // Obtener un producto por su ID
    @GetMapping("buscars/{id}")
    public ResponseEntity<producto> obtenerPorId(@PathVariable Long id) {
        Optional<producto> producto = productoServicio.obtenerProductoPorId(id);
        return producto.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Crear un nuevo producto
    @PostMapping("/agregars")
    public ResponseEntity<producto> guardar(@RequestBody producto producto) {
        producto nuevoProducto = productoServicio.guardarProducto(producto);
        return ResponseEntity.ok(nuevoProducto);
    }

    // Actualizar un producto existente
    @PutMapping("actualizars/{id}")
    public ResponseEntity<producto> actualizar(@PathVariable Long id, @RequestBody producto productoActualizado) {
        Optional<producto> productoActualizadoOptional = productoServicio.actualizarProducto(id, productoActualizado);
        return productoActualizadoOptional.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Eliminar un producto por su ID
    @DeleteMapping("eliminars/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (productoServicio.eliminarProducto(id)) {
            return ResponseEntity.noContent().build();  // 204 No Content
        } else {
            return ResponseEntity.notFound().build();   // 404 Not Found
        }
    }


    private String guardarArchivo(MultipartFile archivo) {
        try {
            String nombreArchivo = System.currentTimeMillis() + "_" + archivo.getOriginalFilename();
            String rutaCarpeta = "uploads/"; // Carpeta dentro del proyecto (o una ruta absoluta si prefieres)

            // Asegurarse que la carpeta exista
            java.nio.file.Path ruta = java.nio.file.Paths.get(rutaCarpeta);
            if (!java.nio.file.Files.exists(ruta)) {
                java.nio.file.Files.createDirectories(ruta);
            }

            // Guardar el archivo
            java.nio.file.Path archivoPath = ruta.resolve(nombreArchivo);
            archivo.transferTo(archivoPath.toFile());

            // Retorna la ruta relativa para acceder desde frontend (si lo sirves desde /uploads)
            return "/uploads/" + nombreArchivo;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @PostMapping("/guardar-con-imagen")
    public ResponseEntity<producto> guardarConImagen(
            @RequestParam("nombreProducto") String nombreProducto,
            @RequestParam("descripcion") String descripcion,
            @RequestParam("precio") Double precio,
            @RequestParam("cantidades") int cantidades,
            @RequestParam("tipo") String tipo,
            @RequestParam("fechaVencimiento") String fechaVencimiento,
            @RequestParam("imagen") MultipartFile imagen) {

        String imagenUrl = guardarArchivo(imagen);

        producto prod = new producto();
        prod.setNombreProducto(nombreProducto);
        prod.setDescripcion(descripcion);
        prod.setPrecio(precio);
        prod.setCantidades(cantidades);
        prod.setTipo(tipo);
        prod.setFechaVencimiento(fechaVencimiento);
        prod.setImagenUrl(imagenUrl);

        producto guardado = productoServicio.guardarProducto(prod);
        return ResponseEntity.ok(guardado);
    }


}
