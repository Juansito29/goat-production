package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Administrador;
import com.example.goatsproduction.Repository.AdministradorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdministradorService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AdministradorRepository administradorRepository;

    // Registrar nuevo administrador
    public Administrador registrarAdministrador(Administrador administrador) {
        if (administradorRepository.findByUsername(administrador.getUsername()).isPresent()) {
            throw new RuntimeException("El email ya está registrado.");
        }

        // 🔒 Encriptar la contraseña antes de guardar
        administrador.setPassword(passwordEncoder.encode(administrador.getPassword()));

        return administradorRepository.save(administrador);
    }

    // Autenticar administrador
    public Administrador autenticarAdministrador(String username, String password) {
        return administradorRepository.findByUsername(username)
                .filter(admin -> passwordEncoder.matches(password, admin.getPassword()))
                .orElseThrow(() -> new RuntimeException("Credenciales incorrectas."));
    }

}
