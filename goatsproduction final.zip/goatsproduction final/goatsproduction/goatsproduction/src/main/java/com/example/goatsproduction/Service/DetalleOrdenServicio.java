package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.detalle_orden;
import com.example.goatsproduction.Repository.ClienteRepository;
import com.example.goatsproduction.Repository.Detalle_ordenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleOrdenServicio {
    @Autowired

    private Detalle_ordenRepository detalle_ordenRepository;
    @Autowired
    private ClienteRepository clienteRepository;

    public List<detalle_orden> obtenerDetallesOrden() {
        return detalle_ordenRepository.findAll();

    }

    public detalle_orden guardarDetalleOrden(detalle_orden Detalle_orden) {
        return detalle_ordenRepository.save(Detalle_orden);
    }

    public Optional<detalle_orden> actualizarDetallesOrdenPorId(Long id, detalle_orden Detalle_orden) {
        return detalle_ordenRepository.findById(id).map(c ->{
          c.setIdDetalleOrden(Detalle_orden.getIdDetalleOrden());
          c.setIdOrden(Detalle_orden.getIdOrden());
          c.setIdProduccion(Detalle_orden.getIdProduccion());
          c.setProductosCantidad(Detalle_orden.getProductosCantidad());
          c.setProductosPrecioCantidad(Detalle_orden.getProductosPrecioCantidad());
            return detalle_ordenRepository.save(c);

        });
    }

    public boolean eliminarDetalleOrden(Long id) {
        if (detalle_ordenRepository.existsById(id)) {
            clienteRepository.deleteById(Math.toIntExact(id));
            return true;
        }
        return false;
    }

}
