package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.produccion;
import com.example.goatsproduction.Repository.ProduccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProduccionServicio {

    @Autowired
    private ProduccionRepository produccionRepository;

    // Obtener todas las producciones
    public List<produccion> obtenerProducciones() {
        return produccionRepository.findAll();
    }


    public Optional<produccion> obtenerProduccionPorId(Long id) {
        return produccionRepository.findById(id);
    }


    public produccion guardarProduccion(produccion produccion) {
        return produccionRepository.save(produccion);
    }


    public Optional<produccion> actualizarProduccion(Long id, produccion produccionActualizada) {
        return produccionRepository.findById(id).map(produccionExistente -> {
            produccionExistente.setFecha_produccion(produccionActualizada.getFecha_produccion());
            produccionExistente.setProduccciones(produccionActualizada.getProduccciones());
            produccionExistente.setCalidad(produccionActualizada.getCalidad());
            return produccionRepository.save(produccionExistente);
        });
    }


    public boolean eliminarProduccion(Long id) {
        if (produccionRepository.existsById(id)) {
            produccionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
