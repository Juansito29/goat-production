package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;


    @Entity
    public class Orden {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id_orden", nullable = false)
        private Long idOrden;

        @Column(name = "fecha", nullable = false)
        private LocalDate fecha;

        @Column(name = "balance_general", nullable = false)
        private float balanceGeneral;

        @Column(name = "total", nullable = false)
        private float total;

        @ManyToOne
        @JoinColumn(name = "id_cliente", nullable = false)
        private com.example.goatsproduction.Entity.cliente cliente;

        @OneToMany(mappedBy = "parentOrden", cascade = CascadeType.ALL)
        private List<com.example.goatsproduction.Entity.Orden> subOrdenes;

        @ManyToOne
        @JoinColumn(name = "id_parent_orden")
        private com.example.goatsproduction.Entity.Orden parentOrden;

        public Orden() {
        }

        public Orden(Long idOrden, LocalDate fecha, float balanceGeneral, float total, com.example.goatsproduction.Entity.cliente cliente, List<Orden> subOrdenes, Orden parentOrden) {
            this.idOrden = idOrden;
            this.fecha = fecha;
            this.balanceGeneral = balanceGeneral;
            this.total = total;
            this.cliente = cliente;
            this.subOrdenes = subOrdenes;
            this.parentOrden = parentOrden;
        }

        public Long getIdOrden() {
            return idOrden;
        }

        public LocalDate getFecha() {
            return fecha;
        }

        public float getBalanceGeneral() {
            return balanceGeneral;
        }

        public float getTotal() {
            return total;
        }

        public com.example.goatsproduction.Entity.cliente getCliente() {
            return cliente;
        }

        public List<com.example.goatsproduction.Entity.Orden> getSubOrdenes() {
            return subOrdenes;
        }

        public com.example.goatsproduction.Entity.Orden getParentOrden() {
            return parentOrden;
        }

        public void setIdOrden(Long idOrden) {
            this.idOrden = idOrden;
        }

        public void setFecha(LocalDate fecha) {
            this.fecha = fecha;
        }

        public void setBalanceGeneral(float balanceGeneral) {
            this.balanceGeneral = balanceGeneral;
        }

        public void setTotal(float total) {
            this.total = total;
        }

        public void setCliente(com.example.goatsproduction.Entity.cliente cliente) {
            cliente = cliente;
        }

        public void setSubOrdenes(List<com.example.goatsproduction.Entity.Orden> subOrdenes) {
            this.subOrdenes = subOrdenes;
        }

        public void setParentOrden(com.example.goatsproduction.Entity.Orden parentOrden) {
            this.parentOrden = parentOrden;
        }
    }


