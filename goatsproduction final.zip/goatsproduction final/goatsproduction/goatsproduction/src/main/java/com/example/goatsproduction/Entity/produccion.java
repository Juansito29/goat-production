package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
public class produccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_produccion", nullable = false)
    private Long id_produccion;

    @Column(name = "fecha_produccion", nullable = false)
    private Date fecha_produccion;

    @OneToMany(mappedBy = "cantidad", cascade = CascadeType.ALL)
    private List<produccion> produccciones;

    @Column(name = "Calidad")
    private char calidad;

    public produccion() {
    }

    public produccion(Long id_produccion, Date fecha_produccion, List<produccion> produccciones, char calidad) {
        this.id_produccion = id_produccion;
        this.fecha_produccion = fecha_produccion;
        this.produccciones = produccciones;
        this.calidad = calidad;
    }

    public Long getId_produccion() {
        return id_produccion;
    }

    public Date getFecha_produccion() {
        return fecha_produccion;
    }

    public List<produccion> getProduccciones() {
        return produccciones;
    }

    public char getCalidad() {
        return calidad;
    }

    public void setId_produccion(Long id_produccion) {
        this.id_produccion = id_produccion;
    }

    public void setFecha_produccion(Date fecha_produccion) {
        this.fecha_produccion = fecha_produccion;
    }

    public void setProduccciones(List<produccion> produccciones) {
        this.produccciones = produccciones;
    }

    public void setCalidad(char calidad) {
        this.calidad = calidad;
    }
}
