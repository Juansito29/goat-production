package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.detalle_orden;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Detalle_ordenRepository extends JpaRepository<detalle_orden, Long> {
}