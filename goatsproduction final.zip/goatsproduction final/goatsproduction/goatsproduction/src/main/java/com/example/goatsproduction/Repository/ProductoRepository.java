package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<producto, Long> {
}