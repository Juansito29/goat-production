package com.example.goatsproduction.Service;


import com.example.goatsproduction.Entity.cliente;
import com.example.goatsproduction.Repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteServicio {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<cliente> obtenerClientes() {
        return clienteRepository.findAll();
    }

    public cliente guardarCliente(cliente cliente) {
        return clienteRepository.save(cliente);
    }
    public Optional<cliente> actualizarCliente(Long clienteId, cliente cliente) {
        return clienteRepository.findById(Math.toIntExact(clienteId)).map( c -> {

            cliente.setIdCliente(cliente.getIdCliente());
            cliente.setNombre(cliente.getNombre());
            cliente.setDireccion( cliente.getDireccion());
            cliente.setTelefono(cliente.getTelefono());
            return clienteRepository.save(cliente);


        });



    }



    public boolean eliminarCliente(Long id) {
        if (clienteRepository.existsById(Math.toIntExact(id))) {
            clienteRepository.deleteById(Math.toIntExact(id));
            return true;
        }
        return false;

    }
}
