package com.example.goatsproduction.Entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class detalle_orden {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle_orden", nullable = false)
    private Long idDetalleOrden;

    @Column(name = "id_orden", nullable = false)
    private Long idOrden;

    @Column(name = "id_produccion", nullable = false)
    private Long idProduccion;

    @OneToMany(mappedBy = "detalleOrden", cascade = CascadeType.ALL)
    private List<producto> productosCantidad;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "detalle_orden_precio_cantidad",
            joinColumns = @JoinColumn(name = "id_detalle_orden"),
            inverseJoinColumns = @JoinColumn(name = "id_producto")
    )
    private List<producto> productosPrecioCantidad;

    // Constructor vacío
    public detalle_orden() {}

    // Constructor con parámetros
    public detalle_orden(Long idDetalleOrden, Long idOrden, Long idProduccion,
                        List<producto> productosCantidad, List<producto> productosPrecioCantidad) {
        this.idDetalleOrden = idDetalleOrden;
        this.idOrden = idOrden;
        this.idProduccion = idProduccion;
        this.productosCantidad = productosCantidad;
        this.productosPrecioCantidad = productosPrecioCantidad;
    }

    // Getters y Setters
    public Long getIdDetalleOrden() {
        return idDetalleOrden;
    }

    public void setIdDetalleOrden(Long idDetalleOrden) {
        this.idDetalleOrden = idDetalleOrden;
    }

    public Long getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(Long idOrden) {
        this.idOrden = idOrden;
    }

    public Long getIdProduccion() {
        return idProduccion;
    }

    public void setIdProduccion(Long idProduccion) {
        this.idProduccion = idProduccion;
    }

    public List<producto> getProductosCantidad() {
        return productosCantidad;
    }

    public void setProductosCantidad(List<producto> productosCantidad) {
        this.productosCantidad = productosCantidad;
    }

    public List<producto> getProductosPrecioCantidad() {
        return productosPrecioCantidad;
    }

    public void setProductosPrecioCantidad(List<producto> productosPrecioCantidad) {
        this.productosPrecioCantidad = productosPrecioCantidad;
    }
}
