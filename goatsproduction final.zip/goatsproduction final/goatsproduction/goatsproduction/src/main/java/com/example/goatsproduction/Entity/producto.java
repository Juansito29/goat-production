package com.example.goatsproduction.Entity;


import jakarta.persistence.*;

import java.util.List;

@Entity
public class producto {


    @Id

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JoinColumn(name = "id_producto", nullable = false)
    private Long id_producto;

    @Column(name = "nombre_producto", nullable = false)
    private char nombre_producto;

    @Column(name = "descripcion", nullable = false)
    private String descripcion;

    @Column(name = "precio", nullable = false)
    private float precio;

    @OneToMany(mappedBy = "tipo", cascade = CascadeType.ALL)
    private List<producto> productos;
    @ManyToOne
    @JoinColumn(name = "id_detalle_orden")
    private detalle_orden detalleOrden;

    @ManyToMany(mappedBy = "productosPrecioCantidad")
    private List<detalle_orden> detallesOrdenPrecioCantidad;


    public producto() {
    }

    public producto(Long id_producto, char nombre_producto, String descripcion, float precio, List<producto> productos) {
        this.id_producto = id_producto;
        this.nombre_producto = nombre_producto;
        this.descripcion = descripcion;
        this.precio = precio;
        this.productos = productos;
        this.detalleOrden = detalleOrden;
    }

    public Long getId_producto() {
        return id_producto;
    }

    public char getNombre_producto() {
        return nombre_producto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public float getPrecio() {
        return precio;
    }

    public List<producto> getProductos() {
        return productos;
    }

    public detalle_orden getdetalleOrden() {
        return detalleOrden;
    }

    public void setDetalleOrden(detalle_orden detalleOrden) {
        this.detalleOrden = detalleOrden;
    }

    public void setId_producto(Long id_producto) {
        this.id_producto = id_producto;
    }

    public void setNombre_producto(char nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public void setProductos(List<producto> productos) {
        this.productos = productos;
    }
}
