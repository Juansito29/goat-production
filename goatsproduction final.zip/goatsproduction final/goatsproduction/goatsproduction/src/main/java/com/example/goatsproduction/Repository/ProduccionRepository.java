package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.produccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProduccionRepository extends JpaRepository<produccion, Long> {
}