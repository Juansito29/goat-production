package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.cabra;
import com.example.goatsproduction.Service.CabraServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://127.0.0.1/")

public class CabraController {
    @Autowired
    private CabraServicio cabraServicio;

    @GetMapping("/listar")
    public List<cabra> listarCabras() {
        return cabraServicio.obtenerTodas();
    }

    @PostMapping("/agregar")
    public cabra agregarCabra(@RequestBody cabra cabra) {
        return cabraServicio.guardarCabra(cabra);
    }

    @PutMapping("/actualizar/{id}")
    public Optional<cabra> actualizarCabra(@PathVariable Long id, @RequestBody cabra cabra) {
        return cabraServicio.actualizarCabra(id, cabra);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminarCabra(@PathVariable Long id) {
        cabraServicio.eliminarCabra(id);
    }
}
