package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Produccion;
import com.example.goatsproduction.Service.ProduccionServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/producciones")
@CrossOrigin("http://127.0.0.1/")
public class ProduccioController {

    @Autowired
    private ProduccionServicio produccionServicio;

    @GetMapping("/listar") // GET request to /producciones/listar
    public List<Produccion> obtenerTodasLasProducciones() {
        return produccionServicio.obtenerProducciones(); // Calls service method to retrieve all Produccion entities
    }

    @GetMapping("/buscar/{id}") // GET request to /producciones/buscar/{id} (Corrected method name)
    public Optional<Produccion> obtenerProduccionPorId(@PathVariable Long id) { // Parameter type changed to Long
        return produccionServicio.obtenerProduccionPorId(id); // Calls service method to retrieve a specific Produccion by ID
    }

    @PostMapping("/agregar") // POST request to /producciones/agregar
    public Produccion guardarProduccion(@RequestBody Produccion produccion) {
        return produccionServicio.guardarProduccion(produccion); // Calls service method to save the Produccion
    }

    @PutMapping("/actualizar/{id}") // PUT request to /producciones/actualizar/{id}
    public Optional<Produccion> actualizarProduccion(@PathVariable Long id, @RequestBody Produccion produccionActualizada) {
        return produccionServicio.actualizarProduccion(id, produccionActualizada); // Calls service method to update the Produccion
    }

    @DeleteMapping("/eliminar/{id}") // DELETE request to /producciones/eliminar/{id}
    public void eliminarProduccion(@PathVariable Long id) {
        produccionServicio.eliminarProduccion(id); // Calls service method to delete the Produccion
    }
}