package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

@Entity
public class cabra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "Raza", nullable = false)
    private String raza;

    @Column(name = "fechaNacimiento", nullable = false)
    private String fechaNacimiento;

    @Column(name = "fechaFallecimiento", nullable = false)
    private String fechaFallecimiento;

    @Column(name = "estado", nullable = false)
    private String estado;


    public cabra(Long id) {
        this.id = id;
    }

    public cabra(Long id, String nombre, String fechaNacimiento, String fechaFallecimiento, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.raza = raza;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaFallecimiento = fechaFallecimiento;
        this.estado = estado;
    }

    public cabra() {

    }

    public String getNombre() {
        return nombre;
    }

    public String getRaza() {
        return raza;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getFechaFallecimiento() {
        return fechaFallecimiento;
    }

    public String getEstado() {
        return estado;
    }

    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setFechaFallecimiento(String fechaFallecimiento) {
        this.fechaFallecimiento = fechaFallecimiento;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
