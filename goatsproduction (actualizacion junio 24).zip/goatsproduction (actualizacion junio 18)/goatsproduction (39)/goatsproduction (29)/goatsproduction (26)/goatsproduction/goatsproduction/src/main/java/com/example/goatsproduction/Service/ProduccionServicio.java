package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Produccion;
import com.example.goatsproduction.Repository.ProduccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProduccionServicio {

    private final ProduccionRepository produccionRepository;

    @Autowired
    public ProduccionServicio(ProduccionRepository produccionRepository) {
        this.produccionRepository = produccionRepository;
    }

    // Obtener todas las producciones
    public List<Produccion> obtenerProducciones() {
        return produccionRepository.findAll();
    }

    // Guardar una nueva producción
    public Produccion guardarProduccion(Produccion produccion) {
        if (produccion == null || produccion.getLechetotalxdia() == null || produccion.getFechaProduccion() == null || produccion.getRaza() == null) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }

        return produccionRepository.save(produccion);
    }

    // Actualizar una producción existente
    public Produccion actualizarProduccion(Long id, Produccion pActualizada) {
        Produccion existente = produccionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producción no encontrada con ID: " + id));

        existente.setLechetotalxdia(pActualizada.getLechetotalxdia());
        existente.setFechaProduccion(pActualizada.getFechaProduccion());
        existente.setRaza(pActualizada.getRaza());
        existente.setCabra(pActualizada.getCabra());

        return produccionRepository.save(existente);
    }

    // Eliminar una producción
    public void eliminarProduccion(Long id) {
        if (!produccionRepository.existsById(id)) {
            throw new RuntimeException("No se puede eliminar, producción con ID " + id + " no encontrada.");
        }
        produccionRepository.deleteById(id);
    }
}
