package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<cliente, Integer> {
}