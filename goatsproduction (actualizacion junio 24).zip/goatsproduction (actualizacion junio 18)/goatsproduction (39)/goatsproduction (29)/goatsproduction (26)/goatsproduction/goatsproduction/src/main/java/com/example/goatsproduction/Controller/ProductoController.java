package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.producto;
import com.example.goatsproduction.Service.ProductoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin("http://127.0.0.1:5500")
public class ProductoController {

    @Autowired
    private ProductoServicio productoServicio;

    // Obtener todos los productos
    @GetMapping("/listars")
    public ResponseEntity<List<producto>> obtenerTodos() {
        List<producto> productos = productoServicio.obtenerProductos();
        return ResponseEntity.ok(productos);
    }

    // Obtener un producto por su ID
    @GetMapping("buscars/{id}")
    public ResponseEntity<producto> obtenerPorId(@PathVariable Long id) {
        Optional<producto> producto = productoServicio.obtenerProductoPorId(id);
        return producto.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Crear un nuevo producto
    @PostMapping("/agregars")
    public ResponseEntity<producto> guardar(@RequestBody producto producto) {
        producto nuevoProducto = productoServicio.guardarProducto(producto);
        return ResponseEntity.ok(nuevoProducto);
    }

    @PutMapping("/actualizars")
    public ResponseEntity<producto> actualizarPorNombre(
            @RequestParam("nombreProducto") String nombreProducto,
            @RequestBody producto productoActualizado) {

        Optional<producto> productoExistenteOptional = productoServicio.obtenerProductoPorNombre(nombreProducto);

        if (productoExistenteOptional.isEmpty()) {
            return ResponseEntity.notFound().build(); // Devuelve 404 si el producto no existe
        }

        producto productoExistente = productoExistenteOptional.get();

        // Actualiza solo los valores proporcionados en la solicitud
        if (productoActualizado.getDescripcion() != null) {
            productoExistente.setDescripcion(productoActualizado.getDescripcion());
        }
        if (productoActualizado.getPrecio() != null) {
            productoExistente.setPrecio(productoActualizado.getPrecio());
        }
        if (productoActualizado.getCantidades() > 0) {
            productoExistente.setCantidades(productoActualizado.getCantidades());
        }
        if (productoActualizado.getTipo() != null) {
            productoExistente.setTipo(productoActualizado.getTipo());
        }
        if (productoActualizado.getFechaVencimiento() != null) {
            productoExistente.setFechaVencimiento(productoActualizado.getFechaVencimiento());
        }
        if (productoActualizado.getImagenUrl() != null) {
            productoExistente.setImagenUrl(productoActualizado.getImagenUrl());
        }

        productoServicio.guardarProducto(productoExistente);
        return ResponseEntity.ok(productoExistente);
    }



    // Eliminar un producto por su ID
    @DeleteMapping("eliminars/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (productoServicio.eliminarProducto(id)) {
            return ResponseEntity.noContent().build();  // 204 No Content
        } else {
            return ResponseEntity.notFound().build();   // 404 Not Found
        }
    }


    private String guardarArchivo(MultipartFile archivo) {
        try {
            // Para guardar archivo
            String rutaBase = "C:/Users/virgu/Downloads/goatsproduction/uploads/";
            Paths.get(rutaBase); // ✅ funciona
            String nombreArchivo = System.currentTimeMillis() + "_" + archivo.getOriginalFilename();

            java.nio.file.Path ruta = java.nio.file.Paths.get(rutaBase);
            if (!java.nio.file.Files.exists(ruta)) {
                java.nio.file.Files.createDirectories(ruta);
            }

            java.nio.file.Path archivoPath = ruta.resolve(nombreArchivo);
            archivo.transferTo(archivoPath.toFile());

            // Devuelve la URL completa que puede consumir el frontend
            return "http://localhost:8080/uploads/" + nombreArchivo;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    @PostMapping("/guardar-con-imagen")
    public ResponseEntity<producto> guardarConImagen(
            @RequestParam("nombreProducto") String nombreProducto,
            @RequestParam("descripcion") String descripcion,
            @RequestParam("precio") Double precio,
            @RequestParam("cantidades") int cantidades,
            @RequestParam("tipo") String tipo,
            @RequestParam("fechaVencimiento") String fechaVencimiento,
            @RequestParam("imagen") MultipartFile imagen) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        System.out.println("Usuario autenticado: " + auth.getName());
        System.out.println("Roles del usuario: " + auth.getAuthorities());


        String imagenUrl = guardarArchivo(imagen);

        producto prod = new producto();
        prod.setNombreProducto(nombreProducto);
        prod.setDescripcion(descripcion);
        prod.setPrecio(precio);
        prod.setCantidades(cantidades);
        prod.setTipo(tipo);
        prod.setFechaVencimiento(fechaVencimiento);
        prod.setImagenUrl(imagenUrl);

        producto guardado = productoServicio.guardarProducto(prod);
        return ResponseEntity.ok(guardado);
    }


}