package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.producto;
import com.example.goatsproduction.Repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoServicio {

    @Autowired
    private ProductoRepository productoRepository;

    // Obtener todos los productos
    public List<producto> obtenerProductos() {
        return productoRepository.findAll();
    }

    public Optional<producto> obtenerProductoPorNombre(String nombreProducto) {
        List<producto> productos = productoRepository.findByNombreProducto(nombreProducto);
        return productos.isEmpty() ? Optional.empty() : Optional.of(productos.get(0)); // Devuelve el primer producto encontrado
    }

    // Guardar un nuevo producto
    public producto guardarProducto(producto producto) {
        return productoRepository.save(producto);
    }

    // Obtener un producto por su ID
    public Optional<producto> obtenerProductoPorId(Long id) {
        return productoRepository.findById(id);
    }

    // Actualizar un producto existente
    public Optional<producto> actualizarProducto(Long id, producto productoActualizado) {
        return productoRepository.findById(id).map(productoExistente -> {
            productoExistente.setId(productoActualizado.getId()); // Actualizado
            productoExistente.setCantidades(productoActualizado.getCantidades());
            productoExistente.setDescripcion(productoActualizado.getDescripcion());
            productoExistente.setPrecio(productoActualizado.getPrecio());
            productoExistente.setTipo(productoActualizado.getTipo());
            productoExistente.setImagenUrl(productoActualizado.getImagenUrl());

            productoExistente.setFechaVencimiento(productoActualizado.getFechaVencimiento());
            return productoRepository.save(productoExistente);
        });
    }

    // Eliminar un producto por ID
    public boolean eliminarProducto(Long id) {
        if (productoRepository.existsById(id)) {
            productoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}