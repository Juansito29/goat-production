package com.example.goatsproduction.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Orden {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_orden", nullable = false)
    private Long idOrden;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @Column(name = "total", nullable = false)
    private float total;

    @ManyToOne
    @JoinColumn(name = "facturacion_id", nullable = false)
    private Factura factura;
    @ManyToOne
    @JoinColumn(name = "carrito_compra_id") // Esta columna almacena la referencia al carrito
    private Carritocompra carritoCompra;

    // Getters y Setters
    public Long getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(Long idOrden) {
        this.idOrden = idOrden;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public Factura getFacturacion() {
        return factura;
    }

    public void setFacturacion(Factura factura) {
        this.factura = factura;
    }


}