package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Pago;
import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.PagoRepository;
import com.example.goatsproduction.Repository.UsuarioRepository;
import com.example.goatsproduction.Security.AESUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pago")
@CrossOrigin(origins = "*")
public class PagoController {

    @Autowired
    private PagoRepository pagoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @PostMapping
    public Pago guardarPago(@RequestBody Pago pago, Authentication authentication) {
        String username = authentication.getName(); // <- Spring Security da el nombre del usuario autenticado

        Usuario usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        pago.setUsuario(usuario);

        pago.setNumeroTarjeta(AESUtil.encrypt(pago.getNumeroTarjeta()));
        pago.setCvv(AESUtil.encrypt(pago.getCvv()));

        System.out.println("Entró al controlador de pago");

        if (authentication == null) {
            System.out.println("Authentication es null");
            throw new RuntimeException("No autenticado");
        }

        System.out.println("Usuario autenticado: " + authentication.getName());


        return pagoRepository.save(pago);


    }



}