package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service

public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JavaMailSender mailSender;

    public void enviarCorreoRecuperacion(String email) {
        Usuario usuario = usuarioRepository.findByEmail(email).orElse(null);

        if (usuario == null) {
            throw new RuntimeException("Correo no registrado.");
        }

        // Crear token único y guardar con expiración
        String token = UUID.randomUUID().toString();
        usuario.setResetToken(token);
        usuario.setTokenExpiration(LocalDateTime.now().plusMinutes(30));
        usuarioRepository.save(usuario);

        // Enlace con token (ajusta según tu frontend)
        String link = "http://localhost:5500/reestablecer.html?token=" + token;

        // Crear y enviar correo
        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setTo(email);
        mensaje.setSubject("Recuperación de contraseña");
        mensaje.setText("Hola " + usuario.getUsername() + ",\n\nHaz clic en el siguiente enlace para restablecer tu contraseña:\n" + link + "\n\nEste enlace expirará en 30 minutos.");

        mailSender.send(mensaje);
    }

    public List<Usuario> getAllUsuario() {
        return usuarioRepository.findAll();
    }

    public Usuario registrarUsuario(Usuario usuario) {


        // 🔒 Validar si el usuario ya existe por nombre de usuario
        if (usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            throw new RuntimeException("El nombre de usuario ya está en uso.");
        }

        // 🔒 Validar si el correo ya está en uso (opcional, si tu entidad tiene email único)
        if (usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            throw new RuntimeException("El correo electrónico ya está en uso.");
        }

        // 🔐 Codificar contraseña y asignar rol seguro
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuario.setRol("ROLE_USER"); // 👈 Rol fijo y no manipulable por el frontend

        return usuarioRepository.save(usuario);


    }

    // 👇 Método opcional para registrar administradores (solo para uso interno/admins)
    public Usuario registrarAdmin(Usuario usuario) {
        if (usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            throw new RuntimeException("El nombre de usuario ya está en uso.");
        }

        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuario.setRol("ROLE_ADMIN");

        return usuarioRepository.save(usuario);
    }


    public Usuario autenticarUsuario(String username, String password) {
        return usuarioRepository.findByUsername(username)
                .filter(u -> passwordEncoder.matches(password, u.getPassword()))
                .orElse(null);
    }

    public boolean restablecerContrasena(String token, String nuevaContrasena) {
        Usuario usuario = usuarioRepository.findByResetToken(token).orElse(null);
        if (usuario != null && usuario.getTokenExpiration() != null &&
                usuario.getTokenExpiration().isAfter(java.time.LocalDateTime.now())) {

            usuario.setPassword(passwordEncoder.encode(nuevaContrasena));
            usuario.setResetToken(null);
            usuario.setTokenExpiration(null);
            usuarioRepository.save(usuario);
            return true;
        }
        return false;
    }

    public Usuario buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email).orElse(null);
    }


}
