package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Pago;
import com.example.goatsproduction.Repository.PagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PagoServicio {

    @Autowired
    private PagoRepository pagoRepository;

    public Pago guardarPago(Pago pago) {
        return pagoRepository.save(pago);
    }
}