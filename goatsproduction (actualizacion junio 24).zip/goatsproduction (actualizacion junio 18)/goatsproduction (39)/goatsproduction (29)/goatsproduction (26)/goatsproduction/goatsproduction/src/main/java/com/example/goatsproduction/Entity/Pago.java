package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "pago") // Especifica el nombre de la tabla (opcional, pero recomendable)
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "numero_tarjeta", nullable = false, length = 20)
    private String numeroTarjeta;

    @Column(name = "expiracion", nullable = false, length = 7)
    private String expiracion;

    @Column(name = "cvv", nullable = false, length = 4)
    private String cvv;

    @ManyToOne
    private Usuario usuario;

    public Pago() { }

    public Pago(Long id, String nombre, String numeroTarjeta, String expiracion, String cvv, Usuario usuario) {
        this.id = id;
        this.nombre = nombre;
        this.numeroTarjeta = numeroTarjeta;
        this.expiracion = expiracion;
        this.cvv = cvv;
        this.usuario = usuario;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getNumeroTarjeta() { return numeroTarjeta; }
    public void setNumeroTarjeta(String numeroTarjeta) { this.numeroTarjeta = numeroTarjeta; }
    public String getExpiracion() { return expiracion; }
    public void setExpiracion(String expiracion) { this.expiracion = expiracion; }
    public String getCvv() { return cvv; }
    public void setCvv(String cvv) { this.cvv=cvv;}

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}