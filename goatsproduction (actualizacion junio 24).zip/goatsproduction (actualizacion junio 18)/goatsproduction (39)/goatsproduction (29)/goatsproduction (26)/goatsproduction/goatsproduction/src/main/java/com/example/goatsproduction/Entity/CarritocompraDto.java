package com.example.goatsproduction.Entity;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * DTO for {@link Carritocompra}
 */
public class CarritocompraDto implements Serializable {
    private final Long id;
    private final List<List<ItemCarrito>> items;
    private final boolean comprado;

    public CarritocompraDto(Long id, List<List<ItemCarrito>> items, boolean comprado) {
        this.id = id;
        this.items = items;
        this.comprado = comprado;
    }

    public Long getId() {
        return id;
    }

    public List<List<ItemCarrito>> getItems() {
        return items;
    }

    public boolean getComprado() {
        return comprado;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarritocompraDto entity = (CarritocompraDto) o;
        return Objects.equals(this.id, entity.id) &&
                Objects.equals(this.items, entity.items) &&
                Objects.equals(this.comprado, entity.comprado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, items, comprado);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" +
                "id = " + id + ", " +
                "items = " + items + ", " +
                "comprado = " + comprado + ")";
    }
}