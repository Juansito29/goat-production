package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Produccion;
import com.example.goatsproduction.Service.ProduccionServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/producciones")
@CrossOrigin("http://127.0.0.1:5500")
public class ProduccioController {

    private final ProduccionServicio produccionServicio;

    @Autowired
    public ProduccioController(ProduccionServicio produccionServicio) {
        this.produccionServicio = produccionServicio;
    }

    // Agregar nueva producción
    @PostMapping("/agregarp")
    public ResponseEntity<String> agregarProduccion(@RequestBody Produccion produccion) {
        if (produccion.getFechaProduccion() == null || produccion.getLechetotalxdia() == null || produccion.getRaza() == null) {
            return new ResponseEntity<>("Todos los campos son obligatorios.", HttpStatus.BAD_REQUEST);
        }

        try {
            produccionServicio.guardarProduccion(produccion);
            return new ResponseEntity<>("Producción registrada correctamente.", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error al registrar la producción: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Obtener todas las producciones
    @GetMapping("/listarp")
    public ResponseEntity<List<Produccion>> obtenerProducciones() {
        List<Produccion> producciones = produccionServicio.obtenerProducciones();
        if (producciones.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(producciones, HttpStatus.OK);
    }

    // Actualizar una producción existente
    @PutMapping("/actualizar/{id}")
    public ResponseEntity<String> actualizarProduccion(@PathVariable Long id, @RequestBody Produccion produccion) {
        try {
            produccionServicio.actualizarProduccion(id, produccion);
            return new ResponseEntity<>("Producción actualizada correctamente.", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error al actualizar la producción: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Eliminar una producción por ID
    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminarProduccion(@PathVariable Long id) {
        try {
            produccionServicio.eliminarProduccion(id);
            return new ResponseEntity<>("Producción eliminada correctamente.", HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>("Error al eliminar la producción: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
