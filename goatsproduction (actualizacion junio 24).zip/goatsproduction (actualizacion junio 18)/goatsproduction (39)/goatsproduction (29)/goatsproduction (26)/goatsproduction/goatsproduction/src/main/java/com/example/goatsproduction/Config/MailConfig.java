package com.example.goatsproduction.Config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
public class MailConfig {

    @Bean
    public JavaMailSender javaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

        mailSender.setHost("smtp.gmail.com");
        mailSender.setPort(587);
        mailSender.setUsername("virguezrodriguezjuan@gmail.com");
        mailSender.setPassword("vqoq fmpf wzxj sxul");
       // mailSender.setUsername("virguezrodriguezjuan@gmail.com");
        // mailSender.setPassword("vqoq fmpf wzxj sxul");

        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.debug", "true"); // puedes quitarlo en producción

        return mailSender;
    }
}
