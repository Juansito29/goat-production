package com.example.goatsproduction.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.goatsproduction.Entity.cabra;
import com.example.goatsproduction.Repository.CabraRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CabraServicio {
    @Autowired

    private CabraRepository cabraRepository;

    public List<cabra>  obtenerTodas(){
        return cabraRepository.findAll();
    }

    public cabra guardarCabra(cabra Cabra){
        return cabraRepository.save(Cabra);
    }

    public Optional<cabra> actualizarCabra(Long id, cabra Cabra){
        return Optional.ofNullable(cabraRepository.findById(id).map(c -> {
            c.setNombre(Cabra.getNombre());
            c.setRaza(Cabra.getRaza());

            c.setFechaNacimiento(Cabra.getFechaNacimiento());
            c.setFechaFallecimiento(Cabra.getFechaFallecimiento());
            c.setEstado(Cabra.getEstado());
            c.setEstado_Salud(Cabra.getEstado_Salud());
            c.setDescripcion(Cabra.getDescripcion());
            c.setPrecio(Cabra.getPrecio());
            c.setFechaSalidaProduccion(Cabra.getFechaSalidaProduccion());
            return cabraRepository.save(c);
        }).orElse(null));
    }
    public void eliminarCabra(Long id){
        cabraRepository.deleteById(id);}
}