package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Facturacion;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FacturacionRepository extends JpaRepository<Facturacion, Long> {


}
