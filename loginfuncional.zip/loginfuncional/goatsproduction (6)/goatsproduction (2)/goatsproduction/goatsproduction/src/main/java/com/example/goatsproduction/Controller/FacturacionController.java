package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Facturacion;
import com.example.goatsproduction.Service.FacturacionServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/facturas")
@CrossOrigin("*")// El endpoint base para las facturas
public class FacturacionController {

    @Autowired
    private FacturacionServicio facturaServicio;

    // Obtener todas las facturas
    @GetMapping("/listar")
    public ResponseEntity<List<Facturacion>> obtenerFacturas() {
        List<Facturacion> facturas = facturaServicio.obtenerFacturas();
        return new ResponseEntity<>(facturas, HttpStatus.OK);
    }

    // Obtener una factura por su ID
    @GetMapping("buscar/{id}")
    public ResponseEntity<Facturacion> obtenerFacturaPorId(@PathVariable("id") Long id) {
        Optional<Facturacion> factura = facturaServicio.obtenerFacturaPorId(id);
        return factura.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Guardar una nueva factura
    @PostMapping("/agregar")
    public ResponseEntity<Facturacion> guardarFactura(@RequestBody Facturacion factura) {
        Facturacion nuevaFactura = facturaServicio.guardarFactura(factura);
        return new ResponseEntity<>(nuevaFactura, HttpStatus.CREATED);
    }

    // Actualizar una factura existente
    @PutMapping("/atualizar/{id}")
    public ResponseEntity<Facturacion> actualizarFactura(@PathVariable("id") Long id, @RequestBody Facturacion factura) {
        Optional<Facturacion> facturaActualizada = facturaServicio.actualizarFactura(id, factura);
        return facturaActualizada.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Eliminar una factura por ID
    @DeleteMapping("eliminar/{id}")
    public ResponseEntity<Void> eliminarFactura(@PathVariable("id") Long id) {
        boolean eliminado = facturaServicio.eliminarFactura(id);
        return eliminado ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
