package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Produccion;
import com.example.goatsproduction.Service.ProduccionServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

public class ProduccioController {

    @Autowired
    private ProduccionServicio produccionServicio;

    // Obtener todas las producciones
    @GetMapping("/listarp")
    public List<Produccion> obtenerTodasLasProducciones() {
        return produccionServicio.obtenerProducciones();
    }




    // Guardar una nueva producción
    @PostMapping("/agregarp")
    public Produccion guardarProduccion(@RequestBody Produccion produccion) {
        return produccionServicio.guardarProduccion(produccion);
    }

    // Actualizar una producción existente
    @PutMapping("/actualizarp{id}")
    public Optional<Produccion> actualizarProduccion(@PathVariable Long id, @RequestBody Produccion produccionActualizada) {
        return produccionServicio.actualizarProduccion(id, produccionActualizada);
    }

    // Eliminar una producción por ID
    @DeleteMapping("/eliminarp{id}")
    public boolean eliminarProduccion(@PathVariable Long id) {
        return produccionServicio.eliminarProduccion(id);
    }
}
