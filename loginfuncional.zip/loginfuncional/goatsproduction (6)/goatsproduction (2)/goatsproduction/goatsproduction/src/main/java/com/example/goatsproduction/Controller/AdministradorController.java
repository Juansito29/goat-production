package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Administrador;
import com.example.goatsproduction.Service.AdministradorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://127.0.0.1:5500/")
@RestController
@RequestMapping("/api/administradores")
public class AdministradorController {

    @Autowired
    private AdministradorService administradorService;

    // Registro de administrador
    @PostMapping("/registrar")
    public ResponseEntity<?> registrarAdministrador(@RequestBody Administrador administrador) {
        Administrador nuevoAdmin = administradorService.registrarAdministrador(administrador);
        return ResponseEntity.ok(nuevoAdmin);
    }

    // Inicio de sesión de administrador
    @PostMapping("/loginn")
    public ResponseEntity<?> loginAdministrador(@RequestBody Administrador administrador) {
        Administrador adminAutenticado = administradorService.autenticarAdministrador(administrador.getUsername(), administrador.getPassword());
        if (adminAutenticado != null) {
            return ResponseEntity.ok(adminAutenticado);
        } else {
            return ResponseEntity.status(401).body("Administrador o contraseña incorrectos.");
        }
    }
}
