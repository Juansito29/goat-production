package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Facturacion;
import com.example.goatsproduction.Repository.FacturacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FacturacionServicio {

    @Autowired
    private FacturacionRepository facturacionRepository;

    // Obtener todas las facturas
    public List<Facturacion> obtenerFacturas() {
        return facturacionRepository.findAll();
    }

    // Guardar una nueva factura
    public Facturacion guardarFactura(Facturacion factura) {
        return facturacionRepository.save(factura);
    }

    // Obtener una factura por su ID
    public Optional<Facturacion> obtenerFacturaPorId(Long id) {
        return facturacionRepository.findById(id);
    }

    // Actualizar una factura existente
    public Optional<Facturacion> actualizarFactura(Long id, Facturacion facturaActualizada) {
        return facturacionRepository.findById(id).map(facturaExistente -> {
            facturaExistente.setFechaEmision(facturaActualizada.getFechaEmision());
            facturaExistente.setSubtotal(facturaActualizada.getSubtotal());
            facturaExistente.setImpuestos(facturaActualizada.getImpuestos());
            return facturacionRepository.save(facturaExistente);
        });
    }

    // Eliminar una factura por ID
    public boolean eliminarFactura(Long id) {
        if (facturacionRepository.existsById(id)) {
            facturacionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
