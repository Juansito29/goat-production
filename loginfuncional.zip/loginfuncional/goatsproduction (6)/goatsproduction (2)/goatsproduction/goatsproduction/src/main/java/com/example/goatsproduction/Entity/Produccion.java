package com.example.goatsproduction.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "producciones")
public class Produccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;



    @Column(name = "lechetotaldias", nullable = false, length = 50)
    private String lechetotaldias;  // Nueva columna: varchar(50)

    @Column(name = "fecha_produccion", nullable = false)
    private LocalDate fechaProduccion;

    // Constructor vacío
    public Produccion() {
    }

    // Constructor con parámetros
    public Produccion( String lechetotaldias, LocalDate fechaProduccion) {

        this.lechetotaldias = lechetotaldias;
        this.fechaProduccion = fechaProduccion;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }



    public String getlechetotalDias() {
        return lechetotaldias;
    }

    public void setlechetotalDias(String dias) {
        this.lechetotaldias = dias;
    }

    public LocalDate getFechaProduccion() {
        return fechaProduccion;
    }

    public void setFechaProduccion(LocalDate fechaProduccion) {
        this.fechaProduccion = fechaProduccion;
    }

    @Override
    public String toString() {
        return "Produccion{" +
                "id=" + id +

                ", dias='" + lechetotaldias + '\'' +
                ", fechaProduccion=" + fechaProduccion +
                '}';
    }
}
