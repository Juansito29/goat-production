package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Carritocompra;
import com.example.goatsproduction.Entity.producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<producto, Long> {

    // Método para buscar productos por nombre
    List<producto> findByNombreProducto(String nombreProducto);


}
