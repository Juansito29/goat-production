package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Factura;
import com.example.goatsproduction.Repository.FacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    public List<Factura> obtenerFacturas() {
        return facturaRepository.findAll();
    }

    public Factura guardarFactura(Factura factura) {
        if (factura.getProductos() != null) {
            factura.getProductos().forEach(producto -> {
                producto.setFactura(factura);
                producto.setSubtotal(producto.getPrecio() * producto.getCantidad());
            });
        }
        return facturaRepository.save(factura);
    }

    public Optional<Factura> obtenerFacturaPorId(Long id) {
        return facturaRepository.findById(id);
    }

    public Optional<Factura> actualizarFactura(Long id, Factura facturaActualizada) {
        return facturaRepository.findById(id).map(facturaExistente -> {
            facturaExistente.setFecha(facturaActualizada.getFecha());
            facturaExistente.setNumeroFactura(facturaActualizada.getNumeroFactura());
            facturaExistente.setTotal(facturaActualizada.getTotal());
            facturaExistente.setProductos(facturaActualizada.getProductos());

            // Recalcular subtotales al actualizar
            if (facturaExistente.getProductos() != null) {
                facturaExistente.getProductos().forEach(producto -> {
                    producto.setFactura(facturaExistente);
                    producto.setSubtotal(producto.getPrecio() * producto.getCantidad());
                });
            }

            return facturaRepository.save(facturaExistente);
        });
    }

    public boolean eliminarFactura(Long id) {
        if (facturaRepository.existsById(id)) {
            facturaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}