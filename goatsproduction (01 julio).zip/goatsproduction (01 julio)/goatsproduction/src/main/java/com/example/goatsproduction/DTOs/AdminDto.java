package com.example.goatsproduction.DTOs;

public class AdminDto {
    private long id;
    private String Username;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
}
