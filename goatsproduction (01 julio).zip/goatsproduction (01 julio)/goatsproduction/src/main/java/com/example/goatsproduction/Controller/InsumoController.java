package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Insumo;
import com.example.goatsproduction.Service.InsumoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/insumos")
public class InsumoController {

    private final InsumoService insumoService;

    public InsumoController(InsumoService insumoService) {
        this.insumoService = insumoService;
    }

    @GetMapping
    public List<Insumo> getAllInsumos() {
        return insumoService.getAllInsumos();
    }

    @GetMapping("/{id}")
    public Insumo getInsumoById(@PathVariable Long id) {
        return insumoService.getInsumoById(id).orElse(null);
    }

    @PostMapping
    public Insumo createInsumo(@RequestBody Insumo insumo) {
        return insumoService.saveInsumo(insumo);
    }

    @PutMapping("/{id}")
    public Insumo updateInsumo(@PathVariable Long id, @RequestBody Insumo insumo) {
        insumo.setId(id);
        return insumoService.saveInsumo(insumo);
    }

    @DeleteMapping("/{id}")
    public void deleteInsumo(@PathVariable Long id) {
        insumoService.deleteInsumo(id);
    }
}