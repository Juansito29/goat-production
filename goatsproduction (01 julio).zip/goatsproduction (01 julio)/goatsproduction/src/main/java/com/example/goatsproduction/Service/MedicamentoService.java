package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Medicamento;
import com.example.goatsproduction.Repository.MedicamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicamentoService {

    @Autowired
    private MedicamentoRepository medicamentoRepository;

    public List<Medicamento> getAll() {
        return medicamentoRepository.findAll();
    }

    public Optional<Medicamento> getById(Long id) {
        return medicamentoRepository.findById(id);
    }

    public Medicamento save(Medicamento medicamento) {
        return medicamentoRepository.save(medicamento);
    }

    public void delete(Long id) {
        medicamentoRepository.deleteById(id);
    }
}
