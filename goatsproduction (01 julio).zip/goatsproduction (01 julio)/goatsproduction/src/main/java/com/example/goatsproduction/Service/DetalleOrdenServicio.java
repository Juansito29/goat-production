package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Detalle_orden;
import com.example.goatsproduction.Repository.DetallerOrdenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleOrdenServicio {

    @Autowired
    private DetallerOrdenRepository detalleOrdenRepository;

    // Obtener todos los detalles de orden
    public List<Detalle_orden> obtenerDetallesOrden() {
        return detalleOrdenRepository.findAll();
    }

    // Guardar un nuevo detalle de orden
    public Detalle_orden guardarDetalleOrden(Detalle_orden detalleOrden) {
        return detalleOrdenRepository.save(detalleOrden);
    }

    // Obtener un detalle de orden por su ID
    public Optional<Detalle_orden> obtenerDetalleOrdenPorId(Long id) {
        return detalleOrdenRepository.findById(id);
    }

    // Actualizar un detalle de orden existente
    public Optional<Detalle_orden> actualizarDetalleOrden(Long id, Detalle_orden detalleOrdenActualizado) {
        return detalleOrdenRepository.findById(id).map(detalleOrdenExistente -> {
            detalleOrdenExistente.setCantidadesProducto(detalleOrdenActualizado.getCantidadesProducto());
            detalleOrdenExistente.setCantidad(detalleOrdenActualizado.getCantidad());
            detalleOrdenExistente.setPrecioCantidad(detalleOrdenActualizado.getPrecioCantidad());
            return detalleOrdenRepository.save(detalleOrdenExistente);
        });
    }

    // Eliminar un detalle de orden por ID
    public boolean eliminarDetalleOrden(Long id) {
        if (detalleOrdenRepository.existsById(id)) {
            detalleOrdenRepository.deleteById(id);
            return true;
        }
        return false;
    }
}