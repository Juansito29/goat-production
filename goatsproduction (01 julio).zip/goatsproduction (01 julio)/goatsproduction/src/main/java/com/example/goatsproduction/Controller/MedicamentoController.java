package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Medicamento;
import com.example.goatsproduction.Service.MedicamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medicamentos")
@CrossOrigin(origins = "*")
public class MedicamentoController {

    @Autowired
    private MedicamentoService medicamentoService;

    @GetMapping
    public List<Medicamento> getAll() {
        return medicamentoService.getAll();
    }

    @GetMapping("/{id}")
    public Medicamento getById(@PathVariable Long id) {
        return medicamentoService.getById(id).orElse(null);
    }

    @PostMapping
    public Medicamento create(@RequestBody Medicamento medicamento) {
        return medicamentoService.save(medicamento);
    }

    @PutMapping("/{id}")
    public Medicamento update(@PathVariable Long id, @RequestBody Medicamento medicamento) {
        medicamento.setId(id);
        return medicamentoService.save(medicamento);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        medicamentoService.delete(id);
    }
}
