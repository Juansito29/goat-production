package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Medicamento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicamentoRepository extends JpaRepository<Medicamento, Long> {
}
