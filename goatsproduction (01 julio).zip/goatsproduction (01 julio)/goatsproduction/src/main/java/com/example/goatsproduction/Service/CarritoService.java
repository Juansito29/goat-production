package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Carritocompra;
import com.example.goatsproduction.Entity.ItemCarrito;
import com.example.goatsproduction.Entity.producto;
import com.example.goatsproduction.Repository.CarritoCompraRepository;
import com.example.goatsproduction.Repository.ItemCarritoRepository;
import com.example.goatsproduction.Repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CarritoService {

    @Autowired
    private CarritoCompraRepository carritoRepo;

    @Autowired
    private ProductoRepository productoRepo;

    @Autowired
    private ItemCarritoRepository itemRepo;

    public Carritocompra crearCarrito() {
        Carritocompra carrito = new Carritocompra();
        return carritoRepo.save(carrito);
    }

    public Carritocompra agregarProducto(Long carritoId, Long productoId, int cantidad) {
        Carritocompra carrito = carritoRepo.findById(carritoId).orElseThrow(() -> new RuntimeException("Carrito no encontrado"));
        producto producto = productoRepo.findById(productoId).orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        Optional<ItemCarrito> itemExistente = carrito.getItems().stream()
                .filter(item -> item.getProducto().getId().equals(productoId))
                .findFirst();

        if (itemExistente.isPresent()) {
            ItemCarrito item = itemExistente.get();
            item.setCantidad(item.getCantidad() + cantidad);
            itemRepo.save(item);
        } else {
            ItemCarrito nuevoItem = new ItemCarrito();
            nuevoItem.setProducto(producto);
            nuevoItem.setCantidad(cantidad);
            nuevoItem.setCarrito(carrito);
            carrito.getItems().add(nuevoItem);
            itemRepo.save(nuevoItem);
        }

        return carritoRepo.save(carrito);
    }

    public Carritocompra obtenerCarrito(Long id) {
        return carritoRepo.findById(id).orElseThrow(() -> new RuntimeException("Carrito no encontrado"));
    }

    public void eliminarItem(Long itemId) {
        itemRepo.deleteById(itemId);
    }

    public void eliminarCarrito(Long carritoId) {
        carritoRepo.deleteById(carritoId);
    }

    public Carritocompra finalizarCompra(Long carritoId) {
        Carritocompra carrito = carritoRepo.findById(carritoId).orElseThrow(() -> new RuntimeException("Carrito no encontrado"));
        carrito.setComprado(true);
        return carritoRepo.save(carrito);
    }
}
