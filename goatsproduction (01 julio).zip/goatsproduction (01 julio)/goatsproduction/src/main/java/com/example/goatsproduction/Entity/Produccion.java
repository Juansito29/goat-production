package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

@Entity
public class Produccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "fecha_produccion", nullable = false)
    private String fechaProduccion;

    @Column(name = "leche_total_x_dia", nullable = false)
    private Double lechetotalxdia;

    @Column(name = "raza", nullable = false) // Nuevo campo raza
    private String raza;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cabra")
    private cabra cabra;  // Asegúrate de que esta entidad existe

    // Constructor vacío
    public Produccion() {
    }

    // Constructor con parámetros
    public Produccion(String fechaProduccion, Double lechetotalxdia, String raza, cabra cabra) {
        this.fechaProduccion = fechaProduccion;
        this.lechetotalxdia = lechetotalxdia;
        this.raza = raza;
        this.cabra = cabra;
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFechaProduccion() {
        return fechaProduccion;
    }

    public void setFechaProduccion(String fechaProduccion) {
        this.fechaProduccion = fechaProduccion;
    }

    public Double getLechetotalxdia() {
        return lechetotalxdia;
    }

    public void setLechetotalxdia(Double lechetotalxdia) {
        this.lechetotalxdia = lechetotalxdia;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public cabra getCabra() {
        return cabra;
    }

    public void setCabra(cabra cabra) {
        this.cabra = cabra;
    }
}
