package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Insumo;
import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.InsumoRepository;
import com.example.goatsproduction.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InsumoService {

    private final InsumoRepository insumoRepository;
    private final UsuarioRepository usuarioRepository;

    @Autowired
    public InsumoService(InsumoRepository insumoRepository, UsuarioRepository usuarioRepository) {
        this.insumoRepository = insumoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public Usuario findByUsername(String username) {
        return usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }

    public List<Insumo> getAllInsumos() {
        return insumoRepository.findAll();
    }

    public Optional<Insumo> getInsumoById(Long id) {
        return insumoRepository.findById(id);
    }

    public Insumo saveInsumo(Insumo insumo) {
        return insumoRepository.save(insumo);
    }

    public void deleteInsumo(Long id) {
        insumoRepository.deleteById(id);
    }
}
