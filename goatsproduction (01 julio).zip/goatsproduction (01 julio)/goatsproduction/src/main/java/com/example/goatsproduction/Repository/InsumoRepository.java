package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Insumo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InsumoRepository extends JpaRepository<Insumo, Long> {
}
