package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Detalle_orden;
import com.example.goatsproduction.Service.DetalleOrdenServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/detalleorden")
public class DetalleOrdenController {

    @Autowired
    private DetalleOrdenServicio detalleOrdenServicio;

    // Obtener todos los detalles de orden
    @GetMapping
    public ResponseEntity<List<Detalle_orden>> obtenerDetallesOrden() {
        List<Detalle_orden> detallesOrden = detalleOrdenServicio.obtenerDetallesOrden();
        return new ResponseEntity<>(detallesOrden, HttpStatus.OK);
    }

    // Obtener un detalle de orden por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Detalle_orden> obtenerDetalleOrdenPorId(@PathVariable("id") Long id) {
        Optional<Detalle_orden> detalleOrden = detalleOrdenServicio.obtenerDetalleOrdenPorId(id);
        return detalleOrden.map(response -> new ResponseEntity<>(response, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Guardar un nuevo detalle de orden
    @PostMapping
    public ResponseEntity<Detalle_orden> guardarDetalleOrden(@RequestBody Detalle_orden detalleOrden) {
        Detalle_orden nuevoDetalleOrden = detalleOrdenServicio.guardarDetalleOrden(detalleOrden);
        return new ResponseEntity<>(nuevoDetalleOrden, HttpStatus.CREATED);
    }

    // Actualizar un detalle de orden existente
    @PutMapping("/{id}")
    public ResponseEntity<Detalle_orden> actualizarDetalleOrden(
            @PathVariable("id") Long id, @RequestBody Detalle_orden detalleOrdenActualizado) {
        Optional<Detalle_orden> detalleOrden = detalleOrdenServicio.actualizarDetalleOrden(id, detalleOrdenActualizado);
        return detalleOrden.map(response -> new ResponseEntity<>(response, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Eliminar un detalle de orden por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDetalleOrden(@PathVariable("id") Long id) {
        boolean eliminado = detalleOrdenServicio.eliminarDetalleOrden(id);
        return eliminado ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}