package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Carritocompra;
import com.example.goatsproduction.Service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://127.0.0.1:5500/")
@RestController
@RequestMapping("/api/carrito")
public class CarritoCompraController {

    @Autowired
    private CarritoService carritoService;

    @PostMapping
    public ResponseEntity<Carritocompra> crearCarrito() {
        return new ResponseEntity<>(carritoService.crearCarrito(), HttpStatus.CREATED);
    }

    @PostMapping("/{carritoId}/agregar")
    public ResponseEntity<Carritocompra> agregarProducto(
            @PathVariable Long carritoId,
            @RequestParam Long productoId,
            @RequestParam int cantidad) {
        return ResponseEntity.ok(carritoService.agregarProducto(carritoId, productoId, cantidad));
    }

    @GetMapping("/{carritoId}")
    public ResponseEntity<Carritocompra> obtener(@PathVariable Long carritoId) {
        return ResponseEntity.ok(carritoService.obtenerCarrito(carritoId));
    }

    @DeleteMapping("/{carritoId}")
    public ResponseEntity<Void> eliminarCarrito(@PathVariable Long carritoId) {
        carritoService.eliminarCarrito(carritoId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{carritoId}/finalizar")
    public ResponseEntity<Carritocompra> finalizarCompra(@PathVariable Long carritoId) {
        return ResponseEntity.ok(carritoService.finalizarCompra(carritoId));
    }
}