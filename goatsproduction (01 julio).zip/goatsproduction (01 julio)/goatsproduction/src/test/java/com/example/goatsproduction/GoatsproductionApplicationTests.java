package com.example.goatsproduction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoatsproductionApplicationTests {

	@Test
	void contextLoads() {
	}

}
