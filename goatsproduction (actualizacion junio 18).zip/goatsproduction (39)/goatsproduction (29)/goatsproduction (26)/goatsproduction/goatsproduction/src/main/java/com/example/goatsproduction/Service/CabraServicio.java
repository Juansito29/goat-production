package com.example.goatsproduction.Service;

import com.example.goatsproduction.Security.AESUtil;
import com.example.goatsproduction.Entity.cabra;
import com.example.goatsproduction.Repository.CabraRepository;
import com.example.goatsproduction.Controller.CabraController.VacunaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CabraServicio {

    @Autowired
    private CabraRepository cabraRepository;

    // Obtener todas las cabras desencriptando
    public List<cabra> obtenerTodas() {
        return cabraRepository.findAll().stream().map(c -> {
            try {
                c.setNombre(AESUtil.decrypt(c.getNombre()));
                c.setRaza(AESUtil.decrypt(c.getRaza()));
                c.setColor(AESUtil.decrypt(c.getColor()));
                c.setDescripcion(AESUtil.decrypt(c.getDescripcion()));
            } catch (Exception e) {
                System.err.println("Error al desencriptar campos de cabra: " + e.getMessage());
            }
            return c;
        }).toList();
    }

    // Guardar una nueva cabra
    public cabra guardarCabra(cabra cabra) {
        cabra.setNombre(AESUtil.encrypt(cabra.getNombre()));
        cabra.setRaza(AESUtil.encrypt(cabra.getRaza()));
        cabra.setColor(AESUtil.encrypt(cabra.getColor()));
        cabra.setDescripcion(AESUtil.encrypt(cabra.getDescripcion()));
        return cabraRepository.save(cabra);
    }

    // Actualizar cabra existente
    public Optional<cabra> actualizarCabra(Long id, cabra cabra) {
        return cabraRepository.findById(id).map(c -> {
            c.setNombre(AESUtil.encrypt(cabra.getNombre()));
            c.setRaza(AESUtil.encrypt(cabra.getRaza()));
            c.setColor(AESUtil.encrypt(cabra.getColor()));
            c.setFechaNacimiento(cabra.getFechaNacimiento());
            c.setFechaFallecimiento(cabra.getFechaFallecimiento());
            c.setEstado(cabra.getEstado());
            c.setEstadoSalud(cabra.getEstadoSalud());
            c.setDescripcion(AESUtil.encrypt(cabra.getDescripcion()));
            c.setFechaSalidaProduccion(cabra.getFechaSalidaProduccion());
            c.setVacunacion(cabra.getVacunacion());
            return cabraRepository.save(c);
        });
    }

    // Eliminar cabra
    public void eliminarCabra(Long id) {
        cabraRepository.deleteById(id);
    }

    // Obtener vacunas de una cabra
    public List<String> obtenerVacunas(Long id) {
        return cabraRepository.findById(id)
                .map(cabra::getVacunacion)
                .orElse(Collections.emptyList());
    }

    // ✅ Asignar vacunas con validación robusta
    public boolean asignarVacunas(Long id, List<Long> vacunaIds) {
        if (vacunaIds == null || vacunaIds.isEmpty()) {
            System.err.println("La lista de vacunas está vacía o es nula.");
            return false;
        }

        Optional<cabra> opcional = cabraRepository.findById(id);
        if (opcional.isEmpty()) {
            System.err.println("No se encontró la cabra con ID: " + id);
            return false;
        }

        cabra c = opcional.get();
        List<String> nombres = vacunaIds.stream()
                .map(this::nombreVacunaPorId)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        if (nombres.isEmpty()) {
            System.err.println("Ninguna vacuna válida fue proporcionada.");
            return false;
        }

        c.setVacunacion(nombres);
        cabraRepository.save(c);
        return true;
    }

    // Vacunas disponibles
    public List<VacunaDTO> listarVacunasDisponibles() {
        return List.of(
                new VacunaDTO(1L, "Fiebre Aftosa"),
                new VacunaDTO(2L, "Brucelosis"),
                new VacunaDTO(3L, "Carbunco"),
                new VacunaDTO(4L, "Rabia"),
                new VacunaDTO(5L, "Enterotoxemia")
        );
    }

    // Traducir ID a nombre
    private String nombreVacunaPorId(Long id) {
        return switch (id.intValue()) {
            case 1 -> "Fiebre Aftosa";
            case 2 -> "Brucelosis";
            case 3 -> "Carbunco";
            case 4 -> "Rabia";
            case 5 -> "Enterotoxemia";
            default -> {
                System.err.println("ID de vacuna desconocido: " + id);
                yield null;
            }
        };
    }
}
