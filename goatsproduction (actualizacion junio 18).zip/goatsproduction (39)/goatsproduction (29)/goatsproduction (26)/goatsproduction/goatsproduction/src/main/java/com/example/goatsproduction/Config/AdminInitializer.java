package com.example.goatsproduction.Config;


import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.UsuarioRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminInitializer {


    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostConstruct
    public void initAdmin() {
        String usernameAdmin = "admin";
        String emailAdmin = "admin@goats.com";

        boolean existe = usuarioRepository.findByUsername(usernameAdmin).isPresent();

        if (!existe) {
            Usuario admin = new Usuario();
            admin.setUsername(usernameAdmin);
            admin.setEmail(emailAdmin);
            admin.setPassword(passwordEncoder.encode("admin123")); // 🔐 Cambia esta contraseña luego
            admin.setRol("ROLE_ADMIN");

            usuarioRepository.save(admin);
            System.out.println("✅ Admin creado por defecto: usuario=admin, contraseña=admin123");
        } else {
            System.out.println("ℹ️ El usuario admin ya existe, no se creó otro.");
        }
    }
}
