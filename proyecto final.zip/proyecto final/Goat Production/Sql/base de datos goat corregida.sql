create database goat_production;
use goat_production;


drop table finca;

CREATE TABLE Cabras (
    ID_Cabra INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Color VARCHAR(20),
    Estado_PR VARCHAR(20),
    Estado_Salud VARCHAR(50),
    Imagenes TEXT,
    Descripcion TEXT,
    Precio DECIMAL(10, 2),
    Raza VARCHAR(50),
    FechaNacimiento DATE,
    FechaFallecimiento DATE,
    FechaSalidaProduccion DATE
);

drop table cabras;

INSERT INTO Cabras (Nombre, Color, Estado_PR, Estado_Salud, Imagenes, Descripcion, Precio, Raza, FechaNacimiento, FechaFallecimiento, FechaSalidaProduccion)
VALUES
('Luna', 'Blanco', 'Disponible', 'Saludable', 'imagen1.jpg', 'Cabra lechera de alto rendimiento', 1200.50, 'Saanen', '2020-05-12', NULL, '2024-06-10'),
('Sol', 'Marrón', 'En producción', 'Saludable', 'imagen2.jpg', 'Cabra apta para producción de queso', 1500.75, 'Toggenburg', '2019-11-25', NULL, '2024-01-15'),
('Estrella', 'Negro', 'Disponible', 'Saludable', 'imagen3.jpg', 'Cabra joven con excelente genética', 1350.00, 'Alpina', '2021-08-30', NULL, NULL),
('Nube', 'Blanco', 'Retirada', 'Enferma', 'imagen4.jpg', 'Cabra mayor con historial de producción', 850.00, 'Saanen', '2015-04-18', '2024-03-20', '2023-12-05'),
('Rayo', 'Gris', 'En producción', 'Saludable', 'imagen5.jpg', 'Cabra fuerte y resistente', 1450.60, 'Boer', '2020-01-10', NULL, '2024-07-15'),
('Luz', 'Blanco', 'Disponible', 'Saludable', 'imagen6.jpg', 'Cabra ideal para crianza', 1300.00, 'Anglo Nubian', '2021-06-22', NULL, NULL),
('Sombra', 'Negro', 'En producción', 'Saludable', 'imagen7.jpg', 'Cabra especializada en producción de lana', 1250.50, 'Cashmere', '2019-03-15', NULL, '2024-02-18'),
('Copito', 'Blanco', 'Disponible', 'Enferma', 'imagen8.jpg', 'Cabra en tratamiento médico', 800.00, 'Saanen', '2022-02-28', NULL, NULL),
('Flecha', 'Marrón', 'En producción', 'Saludable', 'imagen9.jpg', 'Cabra con excelente adaptabilidad', 1400.00, 'Kiko', '2018-09-12', NULL, '2024-05-01'),
('Trueno', 'Gris', 'Disponible', 'Recuperándose', 'imagen10.jpg', 'Cabra joven con historial médico reciente', 1100.00, 'Boer', '2022-11-03', NULL, NULL);


alter table cabras
drop column id_finca;

create table produccion (
cantidad_dia varchar(50)
);

insert into produccion (cantidad_dia)
values ('30'),
('09'),
('20'),
('10'),
('20'),
('50'),
('11'),
('50'),
('100'),
('30');


drop table produccion;

create table producto (
nombre varchar (50),
decripcion varchar (50),
precio float,
tipo varchar(50)
);
insert into Producto (cantidades, nombre, decripcion, precio, tipo, fecha_vencimiento) values
(1, 'Leche de cabra', 'Leche pasteurizada de cabra', 3.5, 'Lácteo', '2019-03-15'),
(2, 'Queso de cabra', 'Queso artesanal', 8.0, 'Lácteo', '2019-03-15'),
(3, 'Yogur de cabra', 'Yogur natural de cabra', 2.5, 'Lácteo', '2019-03-15'),
(4, 'Crema de cabra', 'Crema elaborada con leche de cabra', 4.0, 'Lácteo', '2019-03-15'),
(5, 'Jabón de leche de cabra', 'Jabón artesanal', 5.0, 'Cosmético', '2019-03-15'),
(6, 'Suero de cabra', 'Suero proteico', 3.0, 'Lácteo', '2019-03-15'),
(7, 'Leche en polvo', 'Leche de cabra deshidratada', 6.0, 'Lácteo', '2019-03-15'),
(8, 'Mantequilla de cabra', 'Mantequilla de leche de cabra', 4.5, 'Lácteo', '2019-03-15'),
(9, 'Queso madurado', 'Queso añejado de cabra', 10.0, 'Lácteo', '2019-03-15'),
(10, 'Helado de leche de cabra', 'Helado artesanal', 3.0, 'Lácteo', '2019-03-15');


alter table producto
add column cantidades int;


create table cliente (
id_cliente int,
nombre varchar (50),
direccion varchar (100),
telefono varchar(15),
email varchar(50)
);

insert into Cliente (id_Cliente, nombre, direccion, telefono, email) values
(1, 'Juan Perez', 'Calle 123', '1234567890', 'juanitoperez@gmail.com'),
(2, 'Maria Lopez', 'Avenida Siempre Viva', '0987654321', 'juanioperez@gmail.com'),
(3, 'Luis Martinez', 'Calle del Sol', '1122334455', 'juanitopeez@gmail.com'),
(4, 'Ana Rojas', 'Plaza Mayor', '6677889900', 'juantoperez@gmail.com'),
(5, 'Carlos Fernández', 'Camino Verde', '3344556677', 'janitoperez@gmail.com'),
(6, 'Diana Gomez', 'Paseo del Río', '4433221100', 'anitoperez@gmail.com'),
(7, 'Pedro Jimenez', 'Avenida Central', '9988776655', 'uanitoperez@gmail.com'),
(8, 'Lucia Torres', 'Callejón Flores', '5566778899', 'jtoperez@gmail.com'),
(9, 'Miguel Castillo', 'Boulevard Norte', '1212121212', 'jnitoperez@gmail.com'),
(10, 'Carla Ruiz', 'Calle de los Olivos', '6543210987', 'janitoperez@gmail.com');

alter table cliente
add column email varchar(50);

drop table cliente;

create table orden (
numero_orden int primary key,
fecha date,
total float
);

insert into Orden (numero_orden, fecha, total) values
(1, '2024-01-10', 100.0),
(2, '2024-01-11',  80.0),
(3, '2024-01-12',  60.0),
(4, '2024-01-13', 90.0),
(5, '2024-01-14', 70.0),
(6, '2024-01-15', 65.0),
(7, '2024-01-16',  75.0),
(8, '2024-01-17',  85.0),
(9, '2024-01-18',  55.0),
(10, '2024-01-19',  95.0);

drop table orden;


create table detalle_orden (
cantidades_producto int,
cantidad int,
precio_cantidad float
);

drop table detalle_orden;

insert into detalle_orden (cantidades_producto, cantidad, precio_cantidad)
values( 05, 30, 7.0),
(06, 70, 8.0),
( 15, 05, 7.5),
(25, 15, 4.0),
( 35, 20, 10.0),
( 45, 12, 6.0),
(55, 09, 6.0),
( 65, 50, 9.0),
( 75, 25, 10.0),
( 06, 3, 9.0);

CREATE TABLE Pago (
    ID_Pago INT AUTO_INCREMENT PRIMARY KEY,
    Metodo_Pago VARCHAR(50) NOT NULL,
    Monto DECIMAL(10, 2) NOT NULL,
    Fecha_Pago DATE NOT NULL
);


INSERT INTO Pago (Metodo_Pago, Monto, Fecha_Pago)
VALUES
('Tarjeta de crédito', 150.00, '2024-11-01'),
('PayPal', 300.00, '2024-11-05'),
('Transferencia bancaria', 450.50, '2024-11-10'),
('Efectivo', 200.00, '2024-11-15'),
('Tarjeta de débito', 350.75, '2024-11-20'),
('Tarjeta de crédito', 180.25, '2024-11-21'),
('PayPal', 275.50, '2024-11-22'),
('Efectivo', 90.00, '2024-11-23'),
('Transferencia bancaria', 400.00, '2024-11-24'),
('Tarjeta de crédito', 210.00, '2024-11-25');


CREATE TABLE Facturacion (
    ID_Factura INT AUTO_INCREMENT PRIMARY KEY,
    Fecha_Emision DATE NOT NULL,
    Subtotal DECIMAL(10, 2) NOT NULL,
    Impuestos DECIMAL(10, 2) NOT NULL
);

INSERT INTO Facturacion (Fecha_Emision, Subtotal, Impuestos)
VALUES
('2024-11-01', 130.00, 20.00),
('2024-11-05', 260.00, 40.00),
('2024-11-10', 400.00, 50.50),
('2024-11-15', 180.00, 20.00),
('2024-11-20', 300.75, 50.00),
('2024-11-21', 150.00, 30.25),
('2024-11-22', 250.00, 25.50),
('2024-11-23', 80.00, 10.00),
('2024-11-24', 350.00, 50.00),
('2024-11-25', 190.00, 20.00);

select * from cabras;
select * from produccion;
select * from producto;
select * from cliente;
select * from detalle_orden;
select * from orden;
select * from Facturacion;