let carrito = [];
let total = 0;

// Productos iniciales
const productos = [
    { id: 1, imagen: "Leche de Cabra.jpeg", nombre: "Leche de Cabra", precio: 16000 },
    { id: 2, imagen: "Queso de Cabras Para Untar.jpeg", nombre: "Queso de Cabra para Untar", precio: 15700 },
    { id: 3, imagen: "Queso Fresco de Cabra.jpeg", nombre: "Queso Fresco de Cabra", precio: 20750 },
    { id: 4, imagen: "Queso Tipo Feta con Oregano.jpeg", nombre: "Queso Tipo Feta con Orégano", precio: 17000 },
    { id: 5, imagen: "Queso Picante.jpeg", nombre: "Queso Tipo Feta con Pimienta Roja", precio: 17000 },
    { id: 6, imagen: "queso feta.jpeg", nombre: "Queso Tipo Feta en Salmuera", precio: 16500 },
    { id: 7, imagen: "Queso Al Vacio.jpeg", nombre: "Queso Tipo Feta al Vacío", precio: 28000 },
];

// Cargar productos al carrusel
function cargarProductos() {
    const carousel = document.getElementById('carousel');
    productos.forEach((producto) => {
        const li = document.createElement('li');
        li.innerHTML = `
            <img src="${producto.imagen}" alt="${producto.nombre}" onerror="this.src='default-image.jpg'">
            <h3>${producto.nombre}</h3>
            <p>$${producto.precio}</p>
            <button onclick="addToCart(${producto.id})">Agregar al carrito</button>
        `;
        carousel.appendChild(li);
    });
}

// Añadir producto al carrito
function addToCart(productId) {
    const product = productos.find(p => p.id === productId);
    const existingItem = carrito.find(item => item.id === productId);

    if (existingItem) {
        // Incrementar la cantidad del producto existente
        existingItem.quantity++;
    } else {
        // Añadir el producto al carrito con cantidad inicial 1
        carrito.push({ ...product, quantity: 1 });
    }
    actualizarCarrito(); // Asegurarse de actualizar el carrito y recalcular el total
}

// Actualizar carrito
function actualizarCarrito() {
    const carritoContenedor = document.getElementById('carrito');
    carritoContenedor.innerHTML = ''; // Limpiar el contenido actual del carrito
    total = 0; // Reiniciar el total

    carrito.forEach(item => {
        // Calcular el total acumulando el precio * cantidad para cada producto
        total += item.precio * item.quantity;
        const li = document.createElement('li');
        li.innerHTML = `
            ${item.nombre} (x${item.quantity}) - $${(item.precio * item.quantity).toFixed(2)}
            <button onclick="eliminarDelCarrito(${item.id})">Eliminar</button>
        `;
        carritoContenedor.appendChild(li);
    });

    // Mostrar el total actualizado
    document.getElementById('total').textContent = `Total: $${total.toFixed(2)}`;

    // Habilitar o deshabilitar el botón de pago según el contenido del carrito
    document.getElementById('pagarCarrito').disabled = carrito.length === 0;
}

// Eliminar producto del carrito
function eliminarDelCarrito(productId) {
    const index = carrito.findIndex(item => item.id === productId);
    if (index > -1) {
        carrito.splice(index, 1);
    }
    actualizarCarrito(); // Actualizar el carrito y recalcular el total después de eliminar
}

// Vaciar carrito
function vaciarCarrito() {
    carrito = []; // Vaciar el array del carrito
    actualizarCarrito(); // Actualizar la interfaz para reflejar el cambio
}

// Realizar pago
function realizarPago() {
    if (carrito.length === 0) {
        alert("Tu carrito está vacío. Agrega productos antes de pagar.");
        return;
    }

    const detallesPedido = carrito.map(item =>
        `${item.nombre} (x${item.quantity}) - $${(item.precio * item.quantity).toFixed(2)}`
    ).join('\n');

    alert(`Pago realizado con éxito.\n\nDetalles del pedido:\n${detallesPedido}\n\nTotal: $${total.toFixed(2)}`);

    vaciarCarrito(); // Vaciar el carrito después de realizar el pago
}

// Inicializar al cargar
window.onload = () => {
    cargarProductos();
};






