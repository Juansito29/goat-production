package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.cliente;
import com.example.goatsproduction.Service.ClienteServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // Indicates this class is a REST controller
@RequestMapping("/clientes") // Defines the base URL for all requests to this controller
@CrossOrigin("*") // Allows CORS requests from any origin (adjust as needed)
public class ClienteController {

    @Autowired
    private ClienteServicio clienteServicio; // Injects the ClienteServicio dependency

    @GetMapping("/listar") // GET request to /clientes/listar
    public List<cliente> listarClientes() {
        return clienteServicio.obtenerClientes(); // Calls the service method to retrieve all clientes
    }

    @PostMapping("/agregar") // POST request to /clientes/agregar
    public cliente agregarCliente(@RequestBody cliente cliente) { // Receives cliente data in the request body
        return clienteServicio.guardarCliente(cliente); // Calls the service method to save the cliente
    }

    @PutMapping("/actualizar/{id}") // PUT request to /clientes/actualizar/{id}
    public Optional<cliente> actualizarCliente(@PathVariable Long id, @RequestBody cliente cliente) { // Receives cliente data and id from the URL and request body
        return clienteServicio.actualizarCliente(id, cliente); // Calls the service method to update the cliente
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminarCliente(@PathVariable Long id) {
        clienteServicio.eliminarCliente(id);
    }
}