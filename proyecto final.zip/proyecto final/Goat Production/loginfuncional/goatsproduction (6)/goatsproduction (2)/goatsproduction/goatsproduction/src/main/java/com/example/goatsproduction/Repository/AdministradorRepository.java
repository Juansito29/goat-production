package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdministradorRepository extends JpaRepository<Administrador, Long> {
    Administrador findByUsernameAndPassword(String username, String password);
}
