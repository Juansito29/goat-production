package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Produccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProduccionRepository extends JpaRepository<Produccion, Long> {
    // Métodos personalizados si es necesario
}
