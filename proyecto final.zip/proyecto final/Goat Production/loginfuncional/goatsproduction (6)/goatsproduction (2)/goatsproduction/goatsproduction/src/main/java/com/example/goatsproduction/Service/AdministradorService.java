package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Administrador;
import com.example.goatsproduction.Repository.AdministradorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdministradorService {

    @Autowired
    private AdministradorRepository administradorRepository;

    public Administrador registrarAdministrador(Administrador administrador) {
        // Lógica adicional para validar o encriptar la contraseña
        return administradorRepository.save(administrador);
    }

    public Administrador autenticarAdministrador(String username, String password) {
        return administradorRepository.findByUsernameAndPassword(username, password);
    }
}
