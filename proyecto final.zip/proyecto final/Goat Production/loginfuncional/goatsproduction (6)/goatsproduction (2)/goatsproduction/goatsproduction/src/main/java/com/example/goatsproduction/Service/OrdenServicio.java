package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Orden;
import com.example.goatsproduction.Repository.ordenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrdenServicio {

    @Autowired
    private ordenRepository ordenRepository;


    public List<Orden> obtenerOrdenes() {
        return ordenRepository.findAll();
    }


    public Orden guardarOrden(Orden orden) {
        return ordenRepository.save(orden);
    }


    public Optional<Orden> actualizarOrden(Long id, Orden ordenActualizada) {
        return ordenRepository.findById(id).map(ordenExistente -> {
            ordenExistente.setIdOrden(ordenActualizada.getIdOrden());
            ordenExistente.setFecha(ordenActualizada.getFecha());

            ordenExistente.setTotal(ordenActualizada.getTotal());

            return ordenRepository.save(ordenExistente);
        });
    }


    public boolean eliminarOrden(Long id) {
        if (ordenRepository.existsById(id)) {
            ordenRepository.deleteById(id);
            return true;
        }
        return false;
    }
}