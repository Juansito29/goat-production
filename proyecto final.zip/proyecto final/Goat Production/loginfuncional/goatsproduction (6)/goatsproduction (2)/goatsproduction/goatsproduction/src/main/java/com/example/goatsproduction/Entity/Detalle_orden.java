package com.example.goatsproduction.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

@Entity
public class Detalle_orden {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // ID único de cada detalle de orden

    @Column(name = "cantidades_producto", nullable = false)
    private int cantidadesProducto; // Cantidades del producto

    @Column(name = "cantidad", nullable = false)
    private int cantidad;  // Cantidad de productos en la orden

    @Column(name = "precio_cantidad", nullable = false)
    private float precioCantidad; // Precio por cantidad del producto

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getCantidadesProducto() {
        return cantidadesProducto;
    }

    public void setCantidadesProducto(int cantidadesProducto) {
        this.cantidadesProducto = cantidadesProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getPrecioCantidad() {
        return precioCantidad;
    }

    public void setPrecioCantidad(float precioCantidad) {
        this.precioCantidad = precioCantidad;
    }
}
