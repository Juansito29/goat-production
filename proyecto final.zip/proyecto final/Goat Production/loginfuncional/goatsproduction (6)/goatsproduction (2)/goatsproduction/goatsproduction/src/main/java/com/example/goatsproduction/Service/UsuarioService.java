package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Usuario registrarUsuario(Usuario usuario) {
        // Lógica adicional para validar o encriptar la contraseña
        return usuarioRepository.save(usuario);
    }

    public Usuario autenticarUsuario(String username, String password) {
        return usuarioRepository.findByUsernameAndPassword(username, password);
    }
}
