package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.producto;
import com.example.goatsproduction.Service.ProductoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin("*")
public class ProductoController {

    @Autowired
    private ProductoServicio productoServicio;

    // Obtener todos los productos
    @GetMapping("/listar")
    public ResponseEntity<List<producto>> obtenerTodos() {
        List<producto> productos = productoServicio.obtenerProductos();
        return ResponseEntity.ok(productos);
    }

    // Obtener un producto por su ID
    @GetMapping("buscar/{id}")
    public ResponseEntity<producto> obtenerPorId(@PathVariable Long id) {
        Optional<producto> producto = productoServicio.obtenerProductoPorId(id);
        return producto.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Crear un nuevo producto
    @PostMapping("/agregar")
    public ResponseEntity<producto> guardar(@RequestBody producto producto) {
        producto nuevoProducto = productoServicio.guardarProducto(producto);
        return ResponseEntity.ok(nuevoProducto);
    }

    // Actualizar un producto existente
    @PutMapping("actualizar/{id}")
    public ResponseEntity<producto> actualizar(@PathVariable Long id, @RequestBody producto productoActualizado) {
        Optional<producto> productoActualizadoOptional = productoServicio.actualizarProducto(id, productoActualizado);
        return productoActualizadoOptional.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Eliminar un producto por su ID
    @DeleteMapping("eliminar/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (productoServicio.eliminarProducto(id)) {
            return ResponseEntity.noContent().build();  // 204 No Content
        } else {
            return ResponseEntity.notFound().build();   // 404 Not Found
        }
    }
}
