package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Orden;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ordenRepository extends JpaRepository<Orden, Long> {
}