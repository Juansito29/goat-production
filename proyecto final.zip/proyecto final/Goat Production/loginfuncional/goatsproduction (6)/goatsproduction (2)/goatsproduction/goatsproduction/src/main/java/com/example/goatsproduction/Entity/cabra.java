package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
public class cabra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name="Color",nullable = false)
    private String Color;

    @Column(name = "estado", nullable = false)
    private String estado;

    @Column(name="Estado_Salud",nullable = false)
    private  String Estado_Salud;


    @Column(name = "Descripcion", nullable = false)
    private String Descripcion;

    @Column(name="Precio",nullable = false)
    private BigDecimal Precio;


    @Column(name = "Raza", nullable = false)
    private String raza;


    @Column(name = "fechaNacimiento", nullable = false)
    private String fechaNacimiento;

    @Column(name = "fechaFallecimiento", nullable = false)
    private String fechaFallecimiento;

    @Column(name = "FechaSalidaProduccion", nullable = false)
    private String FechaSalidaProduccion;










    public cabra(Long id) {
        this.id = id;
    }

    public cabra(Long id, String nombre, String fechaNacimiento, String fechaFallecimiento, String estado, String Color,String Descripcion, String Estado_Salud, BigDecimal Precio,String FechaSalidaProduccion ) {
        this.id = id;
        this.nombre = nombre;
        this.raza = raza;
        this.Color=Color;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaFallecimiento = fechaFallecimiento;
        this.estado = estado;
        this.Estado_Salud=Estado_Salud;
        this.Precio=Precio;
        this.Descripcion=Descripcion;
        this.FechaSalidaProduccion=FechaSalidaProduccion;
    }

    public cabra() {

    }

    public String getNombre() {
        return nombre;
    }

    public String getRaza() {
        return raza;
    }
    public String getColor() {
        return Color;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getFechaFallecimiento() {
        return fechaFallecimiento;
    }

    public String getEstado() {
        return estado;
    }
    public String getEstado_Salud(){return Estado_Salud;}

    public String getDescripcion() {
        return Descripcion;
    }

    public BigDecimal getPrecio() {return Precio;}

    public String getFechaSalidaProduccion(){return FechaSalidaProduccion;}

    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }
    public void setColor(String Color) {
        this.Color = Color;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setFechaFallecimiento(String fechaFallecimiento) {
        this.fechaFallecimiento = fechaFallecimiento;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setEstado_Salud(String estado_Salud) {Estado_Salud = estado_Salud;}

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public void setPrecio(BigDecimal Precio ) {this.Precio = Precio;}
    public void setFechaSalidaProduccion(String FechaSalidaProduccion){this.FechaSalidaProduccion=FechaSalidaProduccion;}
}
