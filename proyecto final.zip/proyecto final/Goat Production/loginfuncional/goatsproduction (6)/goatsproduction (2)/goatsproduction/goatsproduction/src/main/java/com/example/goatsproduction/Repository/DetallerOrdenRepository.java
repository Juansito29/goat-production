package com.example.goatsproduction.Repository;



import com.example.goatsproduction.Entity.Detalle_orden;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DetallerOrdenRepository extends JpaRepository<Detalle_orden, Long> {
    // Aquí puedes agregar consultas personalizadas si las necesitas
}
