document.addEventListener("DOMContentLoaded", () => {
    const formCabra = document.getElementById("form-cabra");
    const tablaCabras = document.getElementById("tabla-cabras").querySelector("tbody");
    const API_URL = "http://localhost:8080/api/cabras";

    let cabraEnEdicion = null; // Almacena el ID de la cabra en edición

    const mostrarMensaje = (mensaje, tipo) => {
        const mensajeDiv = document.createElement("div");
        mensajeDiv.classList.add("message", tipo === "success" ? "success" : "error");
        mensajeDiv.textContent = mensaje;

        document.body.insertBefore(mensajeDiv, document.querySelector("header").nextSibling);

        setTimeout(() => {
            mensajeDiv.remove();
        }, 3000);
    };

    const obtenerCabras = async () => {
        try {
            const response = await fetch(`http://localhost:8080/api/cabras/listar`);
            if (!response.ok) throw new Error("Error al obtener cabras.");

            const cabras = await response.json();
            tablaCabras.innerHTML = ""; // Limpiar tabla antes de agregar nuevas filas

            cabras.forEach((cabra) => {
                const fila = document.createElement("tr");
                fila.innerHTML = `
                    <td>${cabra.id}</td>
                    <td>${cabra.color || "N/A"}</td>
                    <td>${cabra.descripcion}</td>
                    <td>${cabra.estadoSalud}</td>
                    <td>${cabra.fechaSalidaProduccion || "N/A"}</td>
                    <td>${cabra.precio}</td>
                    <td>${cabra.estado}</td>
                    <td>${cabra.fechaFallecimiento || "N/A"}</td>
                    <td>${cabra.fechaNacimiento}</td>
                    <td>${cabra.nombre}</td>
                    <td>${cabra.raza}</td>
                    <td>
                        <button onclick="editarCabra(${cabra.id})">Editar</button>
                        <button onclick="eliminarCabra(${cabra.id})">Eliminar</button>
                    </td>
                `;
                tablaCabras.appendChild(fila);
            });
        } catch (error) {
            mostrarMensaje(`Error al obtener cabras: ${error.message}`, "error");
        }
    };

    formCabra.addEventListener("submit", async (event) => {
        event.preventDefault();

        const cabraData = {
            descripcion: document.getElementById("descripcion").value,
            estadoSalud: document.getElementById("estadoSalud").value,
            fechaSalidaProduccion: document.getElementById("fechaSalidaProduccion").value || null,
            precio: parseFloat(document.getElementById("precio").value),
            estado: document.getElementById("estado").value,
            fechaFallecimiento: document.getElementById("fechaFallecimiento").value || null,
            fechaNacimiento: document.getElementById("fechaNacimiento").value,
            nombre: document.getElementById("nombre").value,
            raza: document.getElementById("raza").value,
            color: document.getElementById("color").value,
        };

        try {
            let url = `http://localhost:8080/api/cabras/agregar`;
            let method = "POST";

            if (cabraEnEdicion) {
                url = `${API_URL}actualizar/{id}`; // Usa el ID en edición
                method = "PUT";
            }

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(cabraData),
            });

            if (!response.ok) throw new Error(cabraEnEdicion ? "Error al actualizar cabra." : "Error al registrar cabra.");

            obtenerCabras();
            formCabra.reset();
            mostrarMensaje(cabraEnEdicion ? "Cabra actualizada exitosamente." : "Cabra registrada exitosamente.", "success");
            cabraEnEdicion = null; // Resetear el modo de edición
        } catch (error) {
            mostrarMensaje(`Error: ${error.message}`, "error");
        }
    });

    window.editarCabra = async (id) => {
        try {
            const response = await fetch(`http://localhost:8080/api/cabras/listar`);
            if (!response.ok) throw new Error("Error al obtener los datos de la cabra.");

            const cabras = await response.json();
            const cabra = cabras.find((c) => c.id === id);

            if (!cabra) throw new Error("Cabra no encontrada.");

            // Prellenar el formulario con los datos de la cabra
            document.getElementById("descripcion").value = cabra.descripcion;
            document.getElementById("estadoSalud").value = cabra.estadoSalud;
            document.getElementById("fechaSalidaProduccion").value = cabra.fechaSalidaProduccion || "";
            document.getElementById("precio").value = cabra.precio;
            document.getElementById("estado").value = cabra.estado;
            document.getElementById("fechaFallecimiento").value = cabra.fechaFallecimiento || "";
            document.getElementById("fechaNacimiento").value = cabra.fechaNacimiento;
            document.getElementById("nombre").value = cabra.nombre;
            document.getElementById("raza").value = cabra.raza;
            document.getElementById("color").value = cabra.color || "";

            cabraEnEdicion = id; // Establecer el modo de edición
            mostrarMensaje("Edición habilitada. Actualiza los datos y guarda.", "success");
        } catch (error) {
            mostrarMensaje(`Error al cargar los datos para editar: ${error.message}`, "error");
        }
    };

    window.eliminarCabra = async (id) => {
        if (!confirm("¿Estás seguro de que deseas eliminar esta cabra?")) return;

        try {
            const response = await fetch(`${API_URL}/eliminar/${id}`, {
                method: "DELETE",
            });

            if (!response.ok) throw new Error("Error al eliminar cabra.");

            obtenerCabras();
            mostrarMensaje("Cabra eliminada exitosamente.", "success");
        } catch (error) {
            mostrarMensaje(`Error al eliminar cabra: ${error.message}`, "error");
        }
    };

    obtenerCabras();
});
