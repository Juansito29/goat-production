$(document).ready(function() {
   
    $('.register-form').hide();

    $('#login').click(function() {
        $('.register-form').hide();
        $('.login-form').show();
    });

    $('#registrar').click(function() {
        $('.login-form').hide();
        $('.register-form').show();
    });

    // Manejo del botón de inicio de sesión
    $('#loginBtn').click(function() {
        const username = $('#username').val();
        const password = $('#password').val();
        const role = $('#role').val();  // 'administrador' o 'usuario'

        if (!username || !password) {
            alert('Por favor, complete todos los campos.');
            return;
        }

      
        const loginData = { username, password };

        fetch(`http://localhost:8080/api/usuarios/loginn`, {  
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Usuario o contraseña incorrectos.');
            }
            return response.json();
        })
        .then(data => {
            alert(`¡Bienvenido, ${data.nombre}!`);
            if (role === 'administrador') {
                window.location.href = 'administrador_dashboard.html';
            } else {
                window.location.href = 'usuario_dashboard.html';
            }
        })
        .catch(error => {
            alert('Error: ' + error.message);
        });
    });

    // Manejo del botón de registro
    $('#registerBtn').click(function() {
        const username = $('#regUsername').val();
        const password = $('#regPassword').val();
        const role = $('#regRole').val();  // 'administrador' o 'usuario'

        if (!username || !password) {
            alert('Por favor, complete todos los campos.');
            return;
        }




   
        const registerData = { username, password };

        fetch(`http://localhost:8080/api/usuarios/registrar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(registerData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al registrar el usuario.');
            }
            return response.json();
        })
        .then(data => {
            alert(`Usuario registrado exitosamente como ${role}`);
            // Limpiar campos
            $('#regUsername').val('');
            $('#regPassword').val('');
            $('#regRole').val('');
        })
        .catch(error => {
            alert('Error: ' + error.message);
        });
    });
});
