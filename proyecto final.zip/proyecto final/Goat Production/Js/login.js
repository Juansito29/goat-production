const loginBtn = document.querySelector("#login");
const registrarBtn = document.querySelector("#registrar");
const loginForm= document.querySelector(".login-form");
const registerform = document.querySelector(".register-form");


loginBtn.addEventListener('click', () => {
    loginBtn.style.backgroundColor = "#26574f";
    registrarBtn.style.backgroundColor = "rgba(255, 255, 255, 0.2)";

    loginForm.style.left = "50%";
    registerform.style.left = "50%"

    loginForm.style.opacity = 1;
    registerform.style.opacity = 0;
 
    document.querySelector(".col-1").style.borderRdius = "0 30% 20% 0";

})

registrarBtn.addEventListener('click', () => {
    loginBtn.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
    registrarBtn.style.backgroundColor = "#26574f" ;

     loginForm.style.left = "150%";
    registerform.style.left = "50%";

    loginForm.style.opacity = 0;
    registerform.style.opacity = 1;

    document.querySelector(".col-2").style.borderRdius = "0 20% 30% 0";
})