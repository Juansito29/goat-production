document.addEventListener("DOMContentLoaded", function() {
    const sections = document.querySelectorAll("section");
    const navLinks = document.querySelectorAll(".sidebar a");

    navLinks.forEach(link => {
        link.addEventListener("click", function(e) {
            e.preventDefault();
            const targetId = this.getAttribute("href").substring(1);

            sections.forEach(section => {
                section.classList.remove("active");
            });

            document.getElementById(targetId).classList.add("active");
        });
    });

    // Mostrar la primera sección por defecto
    document.getElementById("registroCabras").classList.add("active");
});
