$(document).ready(function () {
   
   

    // Cargar productos al iniciar
    cargarProductos();

    // Manejo del formulario de registro de producto
    $('#saveProductBtn').click(function () {
        const nombre = $('#nombre').val();
        const tipo = $('#tipo').val();
        const descripcion = $('#descripcion').val();
        const cantidad = $('#cantidad').val();
        const precio = $('#precio').val();
        const fechaVencimiento = $('#fechaVencimiento').val();

        if (!nombre || !tipo || !descripcion || !cantidad || !precio || !fechaVencimiento) {
            alert('Por favor, complete todos los campos.');
            return;
        }

        const productoData = { nombre, tipo, descripcion, cantidad, precio, fechaVencimiento };

        fetch('http://localhost:8080/api/productos/agregar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productoData)
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al guardar el producto.');
                }
                return response.json();
            })
            .then(data => {
                alert(`Producto "${data.nombre}" guardado exitosamente.`);
                $('#productForm')[0].reset(); // Limpiar formulario
                cargarProductos();
            })
            .catch(error => {
                alert('Error: ' + error.message);
            });
    });

    // Cargar productos en la tabla
    function cargarProductos() {
        fetch('http://localhost:8080/api/productos/listar')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al obtener la lista de productos.');
                }
                return response.json();
            })
            .then(productos => {
                const tbody = $('#tabla-productos tbody');
                tbody.empty(); // Limpiar tabla

                productos.forEach(producto => {
                    const row = `
                        <tr>
                            <td>${producto.id}</td>
                            <td>${producto.cantidad}</td>
                            <td>${producto.descripcion}</td>
                            <td>${producto.fechaVencimiento}</td>
                            <td>${producto.nombre}</td>
                            <td>${producto.precio}</td>
                            <td>${producto.tipo}</td>
                            <td>
                                <button class="edit-btn" data-id="${producto.id}">Editar</button>
                                <button class="delete-btn" data-id="${producto.id}">Eliminar</button>
                            </td>
                        </tr>
                    `;
                    tbody.append(row);
                });
            })
            .catch(error => {
                alert('Error: ' + error.message);
            });
    }

    // Manejo del botón de eliminar producto
    $('#tabla-productos').on('click', '.delete-btn', function () {
        const id = $(this).data('id');

        fetch(`http://localhost:8080/api/productos/eliminar/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al eliminar el producto.');
                }
                alert('Producto eliminado exitosamente.');
                cargarProductos();
            })
            .catch(error => {
                alert('Error: ' + error.message);
            });
    });

    // Manejo del botón de editar producto (opcional, se puede expandir)
    $('#tabla-productos').on('click', '.edit-btn', function () {
        const id = $(this).data('id');
        // Aquí podrías mostrar un formulario para editar el producto
        // Cargar datos del producto con fetch si es necesario
    });
});
