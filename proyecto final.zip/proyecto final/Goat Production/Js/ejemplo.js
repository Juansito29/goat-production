// URL del backend
const API_URL = "http://localhost:8080"; // Cambia el puerto si es necesario

// Botones y campos del DOM
const loginBtn = document.getElementById("loginBtn");
const registerBtn = document.getElementById("registerBtn");

// Función para manejar el inicio de sesión
loginBtn.addEventListener("click", async (e) => {
    e.preventDefault(); // Prevenir la recarga de la página
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const user = { username, password };

    try {
        const response = await fetch(`${API_URL}/loginnn`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(user),
        });

        const result = await response.json(); // Asegúrate de manejar la respuesta como JSON
        if (response.ok) {
            alert("Login exitoso: " + result.username); // Mostrar nombre de usuario o mensaje de éxito
        } else {
            alert("Error: " + result);
        }
    } catch (error) {
        console.error("Error al iniciar sesión:", error);
        alert("No se pudo conectar al servidor.");
    }
});

// Función para manejar el registro
registerBtn.addEventListener("click", async (e) => {
    e.preventDefault(); // Prevenir la recarga de la página
    const regUsername = document.getElementById("regUsername").value;
    const regPassword = document.getElementById("regPassword").value;
    const regRole = document.getElementById("regRole").value;

    const newUser = { username: regUsername, password: regPassword, role: regRole };

    try {
        const response = await fetch(`${API_URL}/registrarr`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(newUser),
        });

        const result = await response.json(); // Asegúrate de manejar la respuesta como JSON
        if (response.ok) {
            alert("Usuario registrado con éxito: " + result.username);
        } else {
            alert("Error al registrar usuario.");
        }
    } catch (error) {
        console.error("Error al registrar usuario:", error);
        alert("No se pudo conectar al servidor.");
    }
});
