document.addEventListener("DOMContentLoaded", () => {
    const loginButton = document.getElementById("login");
    const registerButton = document.getElementById("registrar");


$('#loginButton').on('click', function(event) {
    let usuarioIngresado = document.getElementById('#input-user').val();
    let contraseñaIngresada = document.getElementById('#input-password').val();

    fetch('http://localhost:8080/login', {
        method: 'POST', 
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            usuario: usuarioIngresado,
            correo: contraseñaIngresada,
        }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la solicitud');
        }
        return response.json(); 
    })
    .then(data => {
        // Asegurarse de que `data` es un array y tiene la estructura correcta
        if (Array.isArray(data)) {
            const usuarioValido = data.find(usuario => 
                usuario.usuario === usuarioIngresado && 
                usuario.contraseña === contraseñaIngresada 
            );
    
            if (usuarioValido) {
                alert('Inicio de sesión exitoso');
            } else {
                alert('Usuario o contraseña incorrectos');
            }
        } else {
            alert('Respuesta del servidor no válida');
        }
    })
    
    .catch(error => {
        console.error('Hubo un problema con la solicitud Fetch:', error);
        alert('Error al enviar.');
    });

    });


    registerButton.addEventListener("click", async (event) => {
        event.preventDefault(); 

        const email = document.querySelector(".register-form .input-field[placeholder='Email']").value;
        const password = document.querySelector(".register-form .input-field[placeholder='Password']").value;
        const username = email.split("@")[0]; 

        if (!email || !password) {
            alert("⚠️ Por favor, complete todos los campos.");
            return;
        }

        try {
            const response = await fetch("http://localhost:8080/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ username, password, email }),
            });

            if (response.ok) {
                const result = await response.json();
                alert(`✅ Usuario registrado con éxito: ${result.username}. Ya puedes iniciar sesión.`);
            } else {
                alert("❌ Ocurrió un error al registrar el usuario. Por favor, intente nuevamente.");
            }
        } catch (error) {
            console.error("Error durante el registro:", error);
            alert("❌ Ocurrió un error al intentar registrar al usuario. Por favor, intente más tarde.");
        }
    });
});
