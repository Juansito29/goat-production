package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;



    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Usuario> usuario = usuarioRepository.findByUsername(username);

        if (usuario.isPresent()) {
            Usuario u = usuario.get();

            // Extraemos el rol sin el prefijo "ROLE_"
            String rolSinPrefijo = u.getRol().replace("ROLE_", "");

            return User.builder()
                    .username(u.getUsername())
                    .password(u.getPassword())
                    .roles(rolSinPrefijo) // ✅ Ahora sí usa el rol real del usuario
                    .build();
        }

        throw new UsernameNotFoundException("Usuario no encontrado: " + username);
    }
}
