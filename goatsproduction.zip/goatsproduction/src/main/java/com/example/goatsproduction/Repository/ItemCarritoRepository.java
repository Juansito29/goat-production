package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.ItemCarrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemCarritoRepository extends JpaRepository<ItemCarrito, Long> {
}