package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Pago;
import com.example.goatsproduction.Repository.PagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin("http://127.0.0.1:5500")
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PagoRepository pagoRepository;

    // Mostrar formulario de pago
    @GetMapping("/form")
    public String showPaymentForm(Model model) {
        model.addAttribute("pago", new Pago()); // Objeto que se mapea al formulario
        return "payment/form"; // Vista: src/main/resources/templates/payment/form.html
    }

    // Procesar el formulario
    @PostMapping("/submit")
    public String submitPayment(@ModelAttribute("pago") Pago pago, Model model) {
        // Guardar en la base de datos
        pagoRepository.save(pago);

        // Puedes pasar un mensaje de éxito a la vista
        model.addAttribute("message", "Pago procesado correctamente.");

        return "payment/success"; // Vista de éxito: src/main/resources/templates/payment/success.html
    }
}