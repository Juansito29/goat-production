package com.example.goatsproduction.Controller;

import com.example.goatsproduction.DTOs.LoginRequest;
import com.example.goatsproduction.DTOs.LoginResponse;
import com.example.goatsproduction.DTOs.RegistroRequest;
import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Security.JwtUtil;
import com.example.goatsproduction.Service.CustomUserDetailsService;
import com.example.goatsproduction.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("")
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> createToken(@RequestBody LoginRequest request) {

        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

                final UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
                final String jwt = jwtUtil.generateToken(userDetails);
                return ResponseEntity.ok(new LoginResponse(jwt));

    }

    @PostMapping("/register")
    public ResponseEntity<?> registrarUsuario(@RequestBody RegistroRequest request) {
        try {
            Usuario nuevo = new Usuario();
            nuevo.setUsername(request.getUsername());
            nuevo.setPassword(request.getPassword());

            Usuario usuario = usuarioService.registrarUsuario(nuevo);

            return ResponseEntity.ok("Usuario registrado con éxito: " + usuario.getUsername());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }



    }




