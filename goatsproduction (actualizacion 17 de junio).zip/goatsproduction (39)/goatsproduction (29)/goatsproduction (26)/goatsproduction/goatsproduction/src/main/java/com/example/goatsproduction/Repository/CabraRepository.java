package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.cabra;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CabraRepository extends JpaRepository<cabra, Long> {
}