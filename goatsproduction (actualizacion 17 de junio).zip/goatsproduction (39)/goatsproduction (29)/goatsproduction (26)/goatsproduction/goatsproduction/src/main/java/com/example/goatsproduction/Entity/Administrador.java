package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "administradores")
public class Administrador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 100)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @ManyToMany
    @JoinTable(
            name = "administrador_cabra",  // Tabla intermedia
            joinColumns = @JoinColumn(name = "administrador_id"),  // Clave foránea de Administrador
            inverseJoinColumns = @JoinColumn(name = "cabra_id")  // Clave foránea de Cabra
    )

    private Set<cabra> cabras = new HashSet<>();
    @ManyToMany
    @JoinTable(
            name = "administrador_usuario",  // Nombre de la tabla intermedia
            joinColumns = @JoinColumn(name = "administrador_id"),  // Clave foránea de Administrador
            inverseJoinColumns = @JoinColumn(name = "usuario_id")  // Clave foránea de Usuario
    )

    private Set<Usuario> usuarios = new HashSet<>();

    // Constructor vacío
    public Administrador() {}

    //Constructor lleno

    public Administrador(Long id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<cabra> getCabras() {
        return cabras;
    }

    public void setCabras(Set<cabra> cabras) {
        this.cabras = cabras;
    }

    public Set<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
    }
}
