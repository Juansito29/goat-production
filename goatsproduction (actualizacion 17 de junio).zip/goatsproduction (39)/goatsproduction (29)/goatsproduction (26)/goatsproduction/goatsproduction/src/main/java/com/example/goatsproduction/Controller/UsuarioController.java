package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Usuario;
import com.example.goatsproduction.Repository.UsuarioRepository;
import com.example.goatsproduction.Security.JwtUtil;
import com.example.goatsproduction.Service.EmailService;
import com.example.goatsproduction.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@CrossOrigin("http://127.0.0.1:5500/")
@RestController
@RequestMapping("/auth/user")
public class UsuarioController {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private EmailService emailService; // Debes tener este servicio implementado

    @PostMapping("/recuperar")
    public ResponseEntity<String> recuperarPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        Optional<Usuario> userOptional = usuarioRepository.findByEmail(email);

        if (userOptional.isPresent()) {
            Usuario user = userOptional.get();
            String token = UUID.randomUUID().toString();

            user.setResetToken(token);
            user.setTokenExpiration(LocalDateTime.now().plusMinutes(30));
            usuarioRepository.save(user);

            String resetLink = "http://localhost:5500/restaurar.html?token=" + token;

            emailService.sendEmail(email, "Recupera tu contraseña",
                    "Haz clic en el siguiente enlace para restablecer tu contraseña:\n" + resetLink);

            return ResponseEntity.ok("Correo enviado con el enlace de recuperación.");
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Correo no registrado.");
    }

    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody Map<String, String> request) {
        String token = request.get("token");
        String nuevaContrasena = request.get("newPassword");

        boolean resultado = usuarioService.restablecerContrasena(token, nuevaContrasena);
        if (resultado) {
            return ResponseEntity.ok("Contraseña restablecida correctamente.");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Token inválido o expirado.");
        }
    }



    @GetMapping("/obtenerUsuarios")
    public List<Usuario> obtenerUsuarios() {
        return usuarioService.getAllUsuario();
    }

    // Registro de usuario
    @PostMapping("/registrarp")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        Usuario nuevoUsuario = usuarioService.registrarUsuario(usuario);
        return ResponseEntity.ok(nuevoUsuario);
    }

    // Inicio de sesión de usuario
    @PostMapping("/loginp")
    public ResponseEntity<?> loginUsuario(@RequestBody Usuario usuario) {
        Usuario usuarioAutenticado = usuarioService.autenticarUsuario(usuario.getUsername(), usuario.getPassword());
        if (usuarioAutenticado != null) {
            UserDetails userDetails = org.springframework.security.core.userdetails.User
                    .withUsername(usuarioAutenticado.getUsername())
                    .password(usuarioAutenticado.getPassword())
                    .roles("USER")
                    .build();

            String token = jwtUtil.generateToken(userDetails);
            return ResponseEntity.ok().body(Map.of("token", token));
        } else {
            return ResponseEntity.status(401).body("Usuario o contraseña incorrectos.");
        }
    }



}
