package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.cabra;
import com.example.goatsproduction.Service.CabraServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/cabra")
@CrossOrigin(origins = "http://127.0.0.1:5500") // Permitir peticiones desde el frontend
public class CabraController {

    @Autowired
    private CabraServicio cabraServicio;

    // Listar todas las cabras
    @GetMapping("/listarc")
    public List<cabra> listarCabras() {
        return cabraServicio.obtenerTodas();
    }

    // Agregar nueva cabra
    @PostMapping("/agregarc")
    public cabra agregarCabra(@RequestBody cabra cabra) {
        return cabraServicio.guardarCabra(cabra);
    }

    // Actualizar cabra por ID
    @PutMapping("/actualizarc/{id}")
    public Optional<cabra> actualizarCabra(@PathVariable Long id, @RequestBody cabra cabra) {
        return cabraServicio.actualizarCabra(id, cabra);
    }

    // Eliminar cabra por ID
    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<?> eliminarCabra(@PathVariable Long id) {
        cabraServicio.eliminarCabra(id);
        return ResponseEntity.ok().build();
    }

    // Asignar vacunas (IDs) a una cabra
    @PutMapping("/vacunarc/{id}")
    public ResponseEntity<?> asignarVacunas(@PathVariable Long id, @RequestBody List<Long> vacunaIds) {
        boolean resultado = cabraServicio.asignarVacunas(id, vacunaIds);
        if (resultado) {
            return ResponseEntity.ok("Vacunas asignadas correctamente.");
        } else {
            return ResponseEntity.badRequest().body("No se pudo asignar vacunas.");
        }
    }

    // Obtener vacunas asignadas a una cabra
    @GetMapping("/vacunas/{id}")
    public List<String> obtenerVacunas(@PathVariable Long id) {
        return cabraServicio.obtenerVacunas(id);
    }

    // Listar todas las vacunas disponibles (por nombre e ID)
    @GetMapping("/vacunas")
    public List<VacunaDTO> listarVacunasDisponibles() {
        return (List<VacunaDTO>) cabraServicio.listarVacunasDisponibles();
    }

    // DTO interno (puedes moverlo a otro archivo si deseas)
    public static class VacunaDTO {
        public Long id;
        public String nombre;

        public VacunaDTO(Long id, String nombre) {
            this.id = id;
            this.nombre = nombre;
        }
    }
}

