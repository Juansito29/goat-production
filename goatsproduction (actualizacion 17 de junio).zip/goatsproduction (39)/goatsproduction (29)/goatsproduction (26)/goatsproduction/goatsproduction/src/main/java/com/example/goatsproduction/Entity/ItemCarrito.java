package com.example.goatsproduction.Entity;

import jakarta.persistence.*;
@Entity
public class ItemCarrito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private producto producto;

    private int cantidad;


    @ManyToOne
    @JoinColumn(name = "carrito_id")
    private Carritocompra carrito;



    public ItemCarrito(Long id, com.example.goatsproduction.Entity.producto producto, int cantidad, Carritocompra carrito) {
        this.id = id;
        this.producto = producto;
        this.cantidad = cantidad;
        this.carrito = carrito;
    }

    public ItemCarrito() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public com.example.goatsproduction.Entity.producto getProducto() {
        return producto;
    }

    public void setProducto(com.example.goatsproduction.Entity.producto producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Carritocompra getCarrito() {
        return carrito;
    }

    public void setCarrito(Carritocompra carrito) {
        this.carrito = carrito;
    }
}
