package com.example.goatsproduction.Service;
import com.example.goatsproduction.Entity.Carritocompra;
import com.example.goatsproduction.Entity.producto;
import com.example.goatsproduction.Entity.ItemCarrito;
import com.example.goatsproduction.Repository.CarritoCompraRepository;
import com.example.goatsproduction.Repository.ItemCarritoRepository;
import com.example.goatsproduction.Repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CarritoService {

        @Autowired
        private CarritoCompraRepository carritoRepo;

        @Autowired
        private ProductoRepository productoRepo;

        @Autowired
        private ItemCarritoRepository itemRepo;

        public Carritocompra crearCarrito() {
            Carritocompra carrito = new Carritocompra();
            return carritoRepo.save(carrito);
        }

        public Carritocompra agregarProducto(Long carritoId, Long productoId, int cantidad) {
            Carritocompra carrito = carritoRepo.findById(carritoId).orElseThrow();
            producto producto = productoRepo.findById(productoId).orElseThrow();

            ItemCarrito item = new ItemCarrito();
            item.setProducto(producto);
            item.setCantidad(cantidad);
            item.setCarrito(carrito);

            carrito.getItems().add(item);
            return carritoRepo.save(carrito);
        }

        public Carritocompra obtenerCarrito(Long id) {
            return carritoRepo.findById(id).orElseThrow();
        }

        public void eliminarItem(Long itemId) {
            itemRepo.deleteById(itemId);
        }

        public void eliminarCarrito(Long carritoId) {
            carritoRepo.deleteById(carritoId);
        }

        public Carritocompra finalizarCompra(Long carritoId) {
            Carritocompra carrito = carritoRepo.findById(carritoId).orElseThrow();
            carrito.setComprado(true);
            return carritoRepo.save(carrito);
        }
    }


