<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <link rel="stylesheet" href="Css/login.css">
    <title>Document</title>
</head>
<body>
    <div class="form-container">
        <div class="col col-1">
            <div class="image-slayer">
                <img src="img/lo-removebg-preview.png" alt="" class="form-image-main">
                <img src="" alt="" class="form-image-dots">
                <img src="" alt="" class="form-image-coin">
                <img src="" alt="" class="form-image-spring">
                <img src="" alt="" class="form-image-goat">
                <img src="" alt="" class="form-image-cloud">
                <img src="" alt="" class="form-image-stars">
            </div>
            <p class="featured-palabras">Gracias por confiar en <span>Goat Production</span></p>

        </div>
        <div class="col col-2">
            <div class="btn-box">
                <button class="btn btn-1" id="login">Inicio De Sesion</button>
                <button class="btn btn-2" id="registrar">Registrese</button>
            </div>

            <div class="login-form">
                <div class="form-tittle">
                    <span>Inicie Sesion</span>
                </div>
                <div class="form-inputs">
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Username" required>
                        <i class='bx bxs-user icon'></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Password" required>
                        <i class='bx bx-lock icon' ></i>
                    </div>
                    <div class="forgot-pass">
                        <a href="#">Olvidaste tu contraseña?</a>
                    </div>
                    <div class="input-box">
                        <button class="input-submit">
                            <span>Inicie Sesion</span>
                            <i class='bx bx-right-arrow-alt'></i>
                        </button>
                    </div>
                </div>
                <div class="social-login">
                    <i class='bx bxl-google-plus' ></i>
                    <i class='bx bxl-facebook-circle' ></i>
                </div>
            </div>

            <div class="register-form">
                <div class="form-tittle">
                    <span>Crea una nueva cuenta</span>
                </div>
                <div class="form-inputs">
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Email" required>
                        <i class='bx bxs-envelope icon'></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Password" required>
                        <i class='bx bx-lock icon' ></i>
                    </div>
                    <div class="forgot-pass">
                        <a href="#">Olvidaste tu contraseña?</a>
                    </div>
                    <div class="input-box">
                        <button class="input-submit">
                            <span>Registrar</span>
                            <i class='bx bx-right-arrow-alt'></i>
                        </button>
                    </div>
                </div>
                <div class="social-login">
                    <i class='bx bxl-google-plus' ></i>
                    <i class='bx bxl-facebook-circle' ></i>
                </div>
            </div>

        </div>

    </div>
    

    <script src="Js/login.js"></script>
</body>
</html>