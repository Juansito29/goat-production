<?php

if(!empty($_POST["btn-1"])){
    if(empty($_POST["Username"]) and empty($_POST["Password"])){
        echo'<div class="alert alert-danger">LOS CAMPOS ESTAN INCOMPLENTOS O VACIOS"</div>';
}else{
    $Username=$_POST("Username");
    $Password=$_POST("Password");
    $sql=$conexion

}
}
?>