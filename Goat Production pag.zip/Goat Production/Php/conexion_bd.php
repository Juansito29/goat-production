<?php

$conexion=new mysqli("localhost", "root", "","goat_db","");

$conexion->set_charset("utf8");




?>