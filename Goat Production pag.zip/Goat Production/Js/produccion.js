document.getElementById("formulario-produccion").addEventListener("submit", async function (e) {
    e.preventDefault();

  
    const fecha = document.getElementById("fecha").value.trim();
    const cabra = document.getElementById("cabra").value.trim();
    const produccion = parseFloat(document.getElementById("produccion").value);

   
    if (!fecha || !cabra || isNaN(produccion) || produccion <= 0) {
        mostrarMensaje("Por favor, completa los campos correctamente.", "error");
        return;
    }

    const datos = {
        fecha,
        cabra,
        produccion,
    };

    try {
      
        const respuesta = await fetch("https://tufincaapi.com/produccion", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(datos),
        });

     
        if (respuesta.ok) {
            const resultado = await respuesta.json();
            mostrarMensaje("Producción registrada correctamente.", "success");

          
            actualizarEstadisticas(produccion);
        } else {
            mostrarMensaje("Error al registrar la producción. Inténtalo nuevamente.", "error");
        }
    } catch (error) {
        console.error("Error al conectar con la API:", error);
        mostrarMensaje("Hubo un problema al conectar con el servidor.", "error");
    }
});


function mostrarMensaje(mensaje, tipo) {
    const mensajeDiv = document.createElement("div");
    mensajeDiv.textContent = mensaje;
    mensajeDiv.className = `mensaje ${tipo}`;
    document.body.appendChild(mensajeDiv);

    setTimeout(() => {
        mensajeDiv.remove();
    }, 3000);
}


function actualizarEstadisticas(produccion) {
    const totalLitros = document.getElementById("total-litros");
    const numRegistros = document.getElementById("num-registros");

    const totalActual = parseFloat(totalLitros.textContent);
    const registrosActuales = parseInt(numRegistros.textContent);

    totalLitros.textContent = (totalActual + produccion).toFixed(1);
    numRegistros.textContent = registrosActuales + 1;
}
