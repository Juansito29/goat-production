document.getElementById('login').addEventListener('click', async () => {
    const username = document.querySelector('.login-form .input-field[placeholder="Username"]').value;
    const password = document.querySelector('.login-form .input-field[placeholder="Password"]').value;

    if (!username || !password) {
        alert("Por favor, complete todos los campos.");
        return;
    }

    try {
        const response = await fetch('http://localhost:8080/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
        });

        const result = await response.text();
        alert(result);
    } catch (error) {
        console.error(error);
        alert("Ocurrió un error al iniciar sesión.");
    }
});

document.getElementById('registrar').addEventListener('click', async () => {
    const email = document.querySelector('.register-form .input-field[placeholder="Email"]').value;
    const password = document.querySelector('.register-form .input-field[placeholder="Password"]').value;

    if (!email || !password) {
        alert("Por favor, complete todos los campos.");
        return;
    }

    try {
        const response = await fetch('http://localhost:8080/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: email.split('@')[0],
                email,
                password,
            }),
        });

        if (!response.ok) {
            throw new Error("Registro fallido");
        }

        const user = await response.json();
        alert('Usuario registrado exitosamente: ' + user.username);
    } catch (error) {
        console.error(error);
        alert("Ocurrió un error al registrar el usuario.");
    }
});
