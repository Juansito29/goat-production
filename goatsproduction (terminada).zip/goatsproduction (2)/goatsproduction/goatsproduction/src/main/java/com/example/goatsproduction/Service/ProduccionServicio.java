package com.example.goatsproduction.Service;

import com.example.goatsproduction.Entity.Produccion;
import com.example.goatsproduction.Repository.ProduccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProduccionServicio {

    @Autowired
    private ProduccionRepository produccionRepository;

    // Obtener todas las producciones
    public List<Produccion> obtenerProducciones() {
        return produccionRepository.findAll();
    }

    // Obtener una producción por su ID
    public Optional<Produccion> obtenerProduccionPorId(Long id) {
        return produccionRepository.findById(id);
    }

    // Guardar una nueva producción
    public Produccion guardarProduccion(Produccion produccion) {
        return produccionRepository.save(produccion);
    }

    // Actualizar una producción existente
    public Optional<Produccion> actualizarProduccion(Long id, Produccion produccionActualizada) {
        return produccionRepository.findById(id).map(produccionExistente -> {
            // Asumiendo que 'nombreProduccion' y 'fechaProduccion' son atributos válidos de Produccion
            produccionExistente.setNombreProduccion(produccionActualizada.getNombreProduccion());
            produccionExistente.setFechaProduccion(produccionActualizada.getFechaProduccion());

            // Si quieres actualizar los productos relacionados, puedes agregar lógica aquí.
            if (produccionActualizada.getProductos() != null) {
                produccionExistente.setProductos(produccionActualizada.getProductos());
            }

            // Guardar y retornar la producción actualizada
            return produccionRepository.save(produccionExistente);
        });
    }

    // Eliminar una producción por ID
    public boolean eliminarProduccion(Long id) {
        if (produccionRepository.existsById(id)) {
            produccionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
