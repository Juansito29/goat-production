package com.example.goatsproduction.Entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;


@Entity
public class Orden {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_orden", nullable = false)
    private Long idOrden;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;



    @Column(name = "total", nullable = false)
    private float total;



    public Orden() {
    }

    public Orden(Long idOrden, LocalDate fecha,  float total, com.example.goatsproduction.Entity.cliente cliente, List<Orden> subOrdenes, Orden parentOrden) {
        this.idOrden = idOrden;
        this.fecha = fecha;

        this.total = total;

    }

    public Long getIdOrden() {
        return idOrden;
    }

    public LocalDate getFecha() {
        return fecha;
    }



    public float getTotal() {
        return total;
    }





    public void setIdOrden(Long idOrden) {
        this.idOrden = idOrden;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }



    public void setTotal(float total) {
        this.total = total;
    }

    public void setCliente(com.example.goatsproduction.Entity.cliente cliente) {
        cliente = cliente;
    }


}