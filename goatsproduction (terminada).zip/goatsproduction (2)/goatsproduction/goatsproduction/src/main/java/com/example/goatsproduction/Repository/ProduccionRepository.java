package com.example.goatsproduction.Repository;

import com.example.goatsproduction.Entity.Produccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProduccionRepository extends JpaRepository<Produccion, Long> {
}