package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Orden;
import com.example.goatsproduction.Service.OrdenServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/ordenes") // Base URL for all Orden-related requests
public class OrdenController {

    @Autowired
    private OrdenServicio ordenServicio;

    @GetMapping("/listar") // GET request to /ordenes/listar
    public List<Orden> obtenerTodasLasOrdenes() {
        return ordenServicio.obtenerOrdenes(); // Calls service method to retrieve all Ordene entities
    }

    @PostMapping("/agregar") // POST request to /ordenes/agregar
    public Orden guardarOrden(@RequestBody Orden orden) {
        return ordenServicio.guardarOrden(orden); // Calls service method to save the Orden
    }

    @PutMapping("/actualizar/{id}") // PUT request to /ordenes/actualizar/{id}
    public Optional<Orden> actualizarOrden(@PathVariable Long id, @RequestBody Orden ordenActualizada) {
        return ordenServicio.actualizarOrden(id, ordenActualizada); // Calls service method to update the Orden
    }

    @DeleteMapping("/eliminar/{id}") // DELETE request to /ordenes/eliminar/{id}
    public void eliminarOrden(@PathVariable Long id) {
        ordenServicio.eliminarOrden(id); // Calls service method to delete the Orden
    }
}