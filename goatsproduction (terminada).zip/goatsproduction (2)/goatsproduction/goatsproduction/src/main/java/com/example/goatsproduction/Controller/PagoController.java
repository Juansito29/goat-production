package com.example.goatsproduction.Controller;

import com.example.goatsproduction.Entity.Pago;
import com.example.goatsproduction.Service.PagoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pagos")  // El endpoint base para los pagos
public class PagoController {

    @Autowired
    private PagoServicio pagoServicio;

    // Obtener todos los pagos
    @GetMapping
    public ResponseEntity<List<Pago>> obtenerPagos() {
        List<Pago> pagos = pagoServicio.obtenerPagos();
        return new ResponseEntity<>(pagos, HttpStatus.OK);
    }

    // Obtener un pago por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Pago> obtenerPagoPorId(@PathVariable("id") Long id) {
        Optional<Pago> pago = pagoServicio.obtenerPagoPorId(id);
        return pago.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Guardar un nuevo pago
    @PostMapping
    public ResponseEntity<Pago> guardarPago(@RequestBody Pago pago) {
        Pago nuevoPago = pagoServicio.guardarPago(pago);
        return new ResponseEntity<>(nuevoPago, HttpStatus.CREATED);
    }

    // Actualizar un pago existente
    @PutMapping("/{id}")
    public ResponseEntity<Pago> actualizarPago(@PathVariable("id") Long id, @RequestBody Pago pago) {
        Optional<Pago> pagoActualizado = pagoServicio.actualizarPago(id, pago);
        return pagoActualizado.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Eliminar un pago por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPago(@PathVariable("id") Long id) {
        boolean eliminado = pagoServicio.eliminarPago(id);
        return eliminado ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
